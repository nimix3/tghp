﻿<?php
$WEBSERVICE = "https://miogram.net/dojob.php";
		$postData = http_build_query(array(
			'Secret' => '********',
			'Func' => 'SendMessage',
			'Message' => 'سلام ، خوبین؟',
			'Robot' => 'Miogram',
			'Phone' => '+989100000000'
		));
		
		$ch = curl_init();
		curl_setopt($ch,CURLOPT_URL,$WEBSERVICE);
        curl_setopt($ch,CURLOPT_POST, true);
        curl_setopt($ch,CURLOPT_POSTFIELDS,$postData);
        curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,30);
        curl_setopt($ch,CURLOPT_TIMEOUT,60);
        $response = curl_exec($ch);
		curl_close($ch);
			if($response !== FALSE){
				$response = json_decode($response,true);
				print_r($response);
			}
			else echo "Error : Not Response";
?>