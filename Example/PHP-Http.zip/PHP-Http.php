﻿<?php
$WEBSERVICE = "https://miogram.net/dojob.php";
		$postData = http_build_query(array(
			'Secret' => '********',
			'Func' => 'SendMessage',
			'Message' => 'سلام ، خوبین؟',
			'Robot' => 'Miogram',
			'Phone' => '+989100000000'
		));
		
		$context = stream_context_create(array(
			'http' => array(
			'method' => 'POST',
			'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
			'content' => $postData
			)));
		$response = file_get_contents($WEBSERVICE, FALSE, $context);
			if($response !== FALSE){
				$response = json_decode($response,true);
				print_r($response);
			}
			else echo "Error : Not Respond";
?>