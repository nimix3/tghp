﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Windows.Forms;

namespace MioGram.net
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        string Data;
        private void button1_Click(object sender, EventArgs e)
        {
            using (var wb = new WebClient())
{
	wb.Headers["Content-Type"] = "application/x-www-form-urlencoded";
	string API = "https://miogram.net/dojob.php";
    var data = new NameValueCollection();
    data["Secret"] = Secret.Text;
	data["Func"] = Func.Text;
	data["Message"] = Message.Text;
	data["Phone"] = Phone.Text;
    data["Robot"] = Robot.Text;
    data["Misc"] = Misc.Text;
    data["Data"] = Data;

    var response = wb.UploadValues(API, "POST", data);
	string responseX = Encoding.UTF8.GetString(response);
    Result.Text = responseX;
} 
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void FileDialog_Click(object sender, EventArgs e)
        {
            OpenFileDialog FileDialogx = new OpenFileDialog();
            FileDialogx.Filter = "JPEG Files (.jpg)|*.jpg|All Files (*.*)|*.*";
            FileDialogx.FilterIndex = 1;
            FileDialogx.Multiselect = false;
            if (FileDialogx.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    FileStream fs = new FileStream(FileDialogx.FileName,FileMode.Open,FileAccess.Read);
                    byte[] filebytes = new byte[fs.Length];
                    fs.Read(filebytes, 0, Convert.ToInt32(fs.Length));
                    string encodedData = Convert.ToBase64String(filebytes,Base64FormattingOptions.InsertLineBreaks);
                    Data = encodedData; 
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }
    }
}
