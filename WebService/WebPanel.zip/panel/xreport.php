﻿<?php
require_once( '/home/miogram/public_html/fa/wp-load.php' );
require_once( '/home/miogram/public_html/fa/wp-blog-header.php' );
require("../../config.php");
require("../../smart.php");
$DBFILE = "userdata2.db";
if (!is_user_logged_in())
	header("Location: https://miogram.net/fa/wp-login.php?action=login"); 
$current_user = wp_get_current_user();
$Username = $current_user->user_login;
//=====================================================================//
$db = mysqli_connect($dbserver, $dbuser, $dbpass, $dbname); // Connect to Database
if (!$db) {
die("Connection failed: " . mysqli_connect_error()); }
@ mysqli_set_charset($db, "utf8");
//=======================REQUEST METHOD CHECK==========================//
$sql = "SELECT Username,IP,Mcred,Pcred,Vcred,Fcred,Ocred,Mlimit,Plimit,Vlimit,Flimit,canGet,isSuper,robot,Ads,Active FROM $table WHERE Username = '$Username' LIMIT 1";
@ $result = mysqli_query($db,$sql);
if(mysqli_num_rows($result) <= 0)
	header("Location: ".get_home_url());
$data = mysqli_fetch_assoc($result);
@ $MsgCredit = $data["Mcred"];
@ $PhotoCredit = $data["Pcred"];
@ $VideoCredit = $data["Vcred"];
@ $FileCredit = $data["Fcred"];
@ $OtherCredit = $data["Ocred"];
@ $CanGet = $data["canGet"];
@ $isSuper = $data["isSuper"];
@ $Ads = $data["Ads"];
@ $Active = $data["Active"];
@ $PhotoMax = $data["Plimit"]; // To Byte
@ $VideoMax = $data["Vlimit"]; // To Byte
@ $FileMax = $data["Flimit"]; // To Byte
@ $MsgMax = $data["Mlimit"]; // Characters
@ $TheIP = $data["IP"];
@ $Username = $data["Username"];
@ $Robot = $data["robot"];
@ $Page = $_REQUEST["p"];
if(!$Page or $Page<0)
	$Page = 0;
$min = $Page * 25; 
$max = ($Page+1) * 25;

$CACHE = read_ini_file($DBFILE);
$UserRecords = array();
foreach($CACHE as $tok => $user)
{
	if($user == $Username)
	$UserRecords[] = $tok;
}
$UserRecords = array_slice($UserRecords,$min,25);

if($_REQUEST["export"]=="csv")
{
$data = xGetReports($_REQUEST["tok"]);
if($data == "error")
	exit();
$exp = "";
foreach($data as $num => $val)
{
	$exp .= $num.",".$val.PHP_EOL;
}
file_put_contents("export/$Username.csv",$exp);
header("Location: "."export/$Username.csv");
exit();
}
?>

<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!--> <html lang="en" class="no-js"> <!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
	<meta charset="utf-8" />
	<title>سامانه ارسال پيام تلگرام</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1.0" name="viewport" />
	<meta content="" name="description" />
	<meta content="" name="author" />
	<meta name="MobileOptimized" content="320">
	<!-- BEGIN GLOBAL MANDATORY STYLES -->          
	<link href="assets/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
	<link href="assets/plugins/bootstrap/css/bootstrap-rtl.min.css" rel="stylesheet" type="text/css"/>

	<!-- END GLOBAL MANDATORY STYLES -->
	<!-- BEGIN PAGE LEVEL PLUGIN STYLES --> 
	<link href="assets/plugins/gritter/css/jquery.gritter-rtl.css" rel="stylesheet" type="text/css"/>
	<link href="assets/plugins/bootstrap-daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
	<link href="assets/plugins/fullcalendar/fullcalendar/fullcalendar.css" rel="stylesheet" type="text/css"/>
	<link href="assets/plugins/jquery-easy-pie-chart/jquery.easy-pie-chart.css" rel="stylesheet" type="text/css"/>
	<!-- END PAGE LEVEL PLUGIN STYLES -->
	<!-- BEGIN THEME STYLES --> 
	<link href="assets/css/style-metronic-rtl.css" rel="stylesheet" type="text/css"/>
	<link href="assets/css/style-rtl.css" rel="stylesheet" type="text/css"/>
	<link href="assets/css/style-responsive-rtl.css" rel="stylesheet" type="text/css"/>
	<link href="assets/css/plugins-rtl.css" rel="stylesheet" type="text/css"/>
	<link href="assets/css/pages/tasks-rtl.css" rel="stylesheet" type="text/css"/>  
	<link href="assets/css/themes/green.css" rel="stylesheet" type="text/css" id="style_color"/>
	<link href="assets/css/custom-rtl.css" rel="stylesheet" type="text/css"/>
	<script src="assets/plugins/jquery-1.10.2.min.js" type="text/javascript"></script>
	<!-- END THEME STYLES -->

<link href="template/default/css/facebox.css" type="text/css" rel="stylesheet" /> 
<script language="javascript" src="template/default/js/facebox.js"></script>
<script language="javascript" src="template/default/js/ui.js"></script>
<script language="javascript" src="template/default/js/ewp.js"></script>


<script  type="text/javascript" src="chart/charts/highcharts.js"></script>
<script  type="text/javascript" src="chart/charts/modules/exporting.js"></script>
<script  type="text/javascript" src="chart/charts/themes/gray.js"></script>
<!-- alert -->
<script src="template/default/js/jquery.alerts.js" type="text/javascript"></script>
<link href="template/default/css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
<link rel="stylesheet" type="text/css" href="template/default/css/header.css" />
<link rel="stylesheet" type="text/css" href="template/default/css/default.css" />



<script language="javascript" src="template/default/js/jquery-cookie.js"></script>
<script language="javascript" src="calendar/facalander.js"></script>
<script language="javascript" src="calendar/jalali.js"></script>
<script language="javascript" src="calendar/calendar-en.js"></script>
<script language="javascript" src="calendar/calendar-JA.js"></script>
<link media="all" href="css/calendar-win2k-1.css" type="text/css" rel="stylesheet">
<script src="calendar/js_005.js" type="text/javascript"></script>
<script src="calendar/js_006.js" type="text/javascript"></script>
 <script src="calendar/js_003.js" type="text/javascript"></script>



       
	<link rel="shortcut icon" href="https://miogram.net/favicon.ico" />
    
     <script type="text/javascript">
        var browserAlert = false;
        var url = '';
        var browser = '';

        $(document).ready(function () {
            $('a[rel*=facebox]').facebox()
            jQuery.each(jQuery.browser, function (i, val) {
                if (val)
                    browser = i;
            });
            if (browser == "mozilla" && parseFloat(jQuery.browser.version.substr(0, 3)) < 1.5) {
                browserAlert = true;
                url = '<a href="http://www.mozilla.com/en-US/firefox/upgrade.html">دانلود ورژن جديد</a>';
            }
            else if (browser == "msie" && parseFloat(jQuery.browser.version.substr(0, 3)) < 7) {
                browserAlert = true;
                url = '<a href="http://www.microsoft.com/windows/internet-explorer/default.aspx">دانلود ورژن جديد</a>';
            }
            if (browserAlert)
                $.growlUI('مرورگر', 'نسخه مرورگري که شما استفاده مي کنيد قديمي است<br>براي دريافت نسخه جديد بر روي لينک زير کليک نماييد<br>' + url, 10000);
            	$("#confirm_button").click( function() {
					jConfirm('آيا قصد خروج از سامانه را داريد ؟', 'تاييد خروج', function(r) {
						if(r){ window.location="logout.php"};
					});
				});
        });
</script>



</head>
<!-- END HEAD -->
<!-- BEGIN BODY -->
<body class="page-header-fixed">
	<!-- BEGIN HEADER -->   
	<div class="header navbar navbar-inverse navbar-fixed-top">
		<!-- BEGIN TOP NAVIGATION BAR -->
		<div class="header-inner">
			<!-- BEGIN LOGO -->  
			<a class="navbar-brand" href="index.htm">
		
                  
      <img src="logo/default_small.png" alt=""  class="img-responsive" style="width:105px;height:35px" />       
			</a>
            

            
            
			<!-- END LOGO -->
			<!-- BEGIN RESPONSIVE MENU TOGGLER --> 
			<a href="javascript:;" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
			<img src="assets/img/menu-toggler.png" alt="" />
			</a> 
			<!-- END RESPONSIVE MENU TOGGLER -->
			<!-- BEGIN TOP NAVIGATION MENU -->
			<ul class="nav navbar-nav pull-right">
				

				<!-- BEGIN USER LOGIN DROPDOWN -->
				<li class="dropdown user">
					<a href="index.htm#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
					<img alt="" src="assets/img/avatar1_small.jpg"/>
					<span class="username"><?php echo $Username; ?></span>
					<i class="icon-angle-down"></i>
					</a>
					<ul class="dropdown-menu">
						<li>
                        
                        <li><a href="https://miogram.net/fa/wp-login.php?action=lostpassword"><i class="icon-pencil"></i> تغيير کلمه عبور</a>
						</li>

						<li class="divider"></li>
						<li><a href="javascript:;" id="trigger_fullscreen"><i class="icon-move"></i> صفحه کامل</a>
						</li>
						<li><a href="https://miogram.net/fa/wp-login.php?action=logout"><i class="icon-key"></i>خروج</a>
						</li>
					</ul>
				</li>
				<!-- END USER LOGIN DROPDOWN -->
			</ul>
			<!-- END TOP NAVIGATION MENU -->
		</div>
		<!-- END TOP NAVIGATION BAR -->
	</div>
	<!-- END HEADER -->
	<div class="clearfix"></div>
	<!-- BEGIN CONTAINER -->
	<div class="page-container">
		<!-- BEGIN SIDEBAR -->
		<div class="page-sidebar navbar-collapse collapse">
			<!-- BEGIN SIDEBAR MENU -->        
			<ul class="page-sidebar-menu">
				<li>
					<!-- BEGIN SIDEBAR TOGGLER BUTTON -->
					<div class="sidebar-toggler hidden-phone"></div>
					<!-- BEGIN SIDEBAR TOGGLER BUTTON -->
				</li>
				<li>
					<!-- BEGIN RESPONSIVE QUICK SEARCH FORM -->
					<!-- END RESPONSIVE QUICK SEARCH FORM -->
                    <br />
				</li>
		
                <li >
					<a href="index.php">
					<i class="icon-home"></i> 
					<span class="title">صفحه اصلي</span>
					<span class=""></span>
					</a>
				</li>

<li >
			<a href="javascript:;">
			<i class="icon-send"></i> 
			<span class="title">امکانات سامانه</span>
			<span class="arrow"></span>
			</a>
<ul class="sub-menu">
<li class="p13" ><a rev="iframe|850|750" rel="[facebox]" href="send.php"> ارسال پیام تلگرام</a></li>
<li class="p13" ><a rev="iframe|850|750" rel="[facebox]" href="bsend.php"> ارسال انبوه پیام تلگرام</a></li>
<li class="p13" ><a rev="iframe|850|750" rel="[facebox]" href="xsend.php"> ارسال هوشمند پیام تلگرام</a></li>
<li class="p43"><a rev="iframe|850|750" rel="[facebox]" href="wsend.php"> ارسال پیام واتس اپ</a></li>
<li class="p43" ><a href="report.php"  >گزارشات ارسال</a></li>
<li class="p43" ><a href="breport.php"  >گزارشات ارسال انبوه</a></li>
<li class="p43" ><a href="xreport.php"  >گزارشات ارسال هوشمند</a></li>
<li class="p128" ><a rev="iframe|750|350" rel="[facebox]" href="service.php"  > وب سرويس و API</a></li>
<li class="p73" ><a rev="iframe|550|350" rel="[facebox]" href="action.php"  > تنظيمات وب سرويس</a></li>
<li class="p73" ><a rev="iframe|850|750" rel="[facebox]" href="setting.php"  > تنظیمات عامل هوشمند</a></li>
<li class="p123" ><a href="https://miogram.net/fa/%D8%AA%D9%85%D8%A7%D8%B3/"  >پشتيباني و کمک</a></li>
<li class="p123" ><a href="https://miogram.net/fa/%D9%85%D8%B3%D8%AA%D9%86%D8%AF%D8%A7%D8%AA/"  >مستندات</a></li>
<li class="p123" ><a href="https://miogram.net/fa/%D8%A2%D9%85%D9%88%D8%B2%D8%B4/"  >راهنما و آموزش</a></li>
<li class="p123" ><a href="https://miogram.net/fa/%D8%A2%D9%85%D9%88%D8%B2%D8%B4-%D9%BE%D8%A7%D9%86%D9%84-%DA%A9%D8%A7%D8%B1%D8%A8%D8%B1%DB%8C/"  >آموزش پانل کاربری</a></li>
<li class="p123" ><a href="https://miogram.net/fa/%D8%AF%D8%B1%D8%A8%D8%A7%D8%B1%D9%87-%D9%85%DB%8C%D9%88%DA%AF%D8%B1%D8%A7%D9%85/"  >درباره میوگرام</a></li>
</ul></li>	
                <li >
					<a href="https://miogram.net/fa/%D9%82%D9%88%D8%A7%D9%86%DB%8C%D9%86/">
					<i class="icon-home"></i> 
					<span class="title">قوانين و ضوابط</span>
					<span class=""></span>
					</a>
				</li>
				<li >
					<a href="miostack.php">
					<i class="icon-home"></i> 
					<span class="title">MioStack Project</span>
					<span class=""></span>
					</a>
				</li>
                <li >
					<a href="https://miogram.net/fa/wp-login.php?action=logout">
					<i class="icon-home"></i> 
					<span class="title">خروج از سامانه</span>
					<span class=""></span>
					</a>
				</li>
</ul>

			<!-- END SIDEBAR MENU -->
		</div>
		<!-- END SIDEBAR -->
		<!-- BEGIN PAGE -->
		<div class="page-content">

			<!-- /.modal -->

			<!-- BEGIN PAGE HEADER-->
			<div class="row">
				<div class="col-md-12">
                <div  style="width: 100%;">
                
					<!-- BEGIN PAGE TITLE & BREADCRUMB-->
					<h3 class="page-title">
						<?php 
						if($Active)
							echo "پانل کاربري سامانه تلگرام"." (فعال)"; 
					    else 
							echo "پانل کاربري سامانه تلگرام"." (غير فعال)"; 
						?>				</h3>
                                        
                    <ul class="page-breadcrumb breadcrumb">
						
						<li><a class="btn purple"  href="https://miogram.net/fa/shop/" style="width: 140px;color:#fff;">شارژ حساب</a></li>
                                                <li><a class="btn green" rev="iframe|850|750" rel="[facebox]" href="send.php" style="width: 140px;color:#fff;">ارسال پيام</a></li>
                                                <li><a class="btn red" rev="iframe|750|350" rel="[facebox]" href="service.php" style="width: 140px;color:#fff;">وب سرويس API</a></li>
												<li><a class="btn blue" rev="iframe|850|750" rel="[facebox]" href="setting.php" style="width: 140px;color:#fff;">تنظیمات عامل ها</a></li>
						<li class="pull-right">
								<?php 
								if(!$Active)
								echo '<div id="dashboard-report-range"  class="dashboard-date-range tooltips" data-placement="top" data-original-title="تماس با ما" onclick="window.location.href='."'https://miogram.net/fa/%D9%81%D8%B9%D8%A7%D9%84%D8%B3%D8%A7%D8%B2%DB%8C/'".';">'.
							          '<span class="label label-danger"> فعال سازي حساب کاربري </span>';
								else echo '<div id="dashboard-report-range"  class="dashboard-date-range tooltips" data-placement="top" data-original-title="تماس با ما" onclick="window.location.href='."'https://miogram.net/fa/%D8%AA%D9%85%D8%A7%D8%B3/'".';">'.
							          '<span class="label label-danger"> تماس با بخش پشتيباني </span>';	  
								?>
								<span></span>
							</div>
						</li>
					</ul>
					<!-- END PAGE TITLE & BREADCRUMB-->
				</div>
                </div>
			</div>
			<!-- END PAGE HEADER-->
		
 
		




<div class="row">
<div class="col-lg-2 col-md-2 col-sm-4 col-xs-12">
	<div class="dashboard-stat purple">
		<div class="visual">
			<i class="icon-support1"></i>
		</div>
		<div class="details">
			<div class="number">
			 <?php echo $MsgCredit; ?>
			</div>
			<div class="desc">                           
				اعتبار پيام متني
			</div>
		</div>
		<a href="https://miogram.net/fa/%D9%85%D8%AD%D8%AF%D9%88%D8%AF%DB%8C%D8%AA/" class="more">
		&nbsp;حداکثر طول مجاز : <?php echo $MsgMax; ?> <i class="m-icon-swapright m-icon-white"></i>
		</a>                 
	</div>
</div>
<div class="col-lg-2 col-md-2 col-sm-4 col-xs-12">
	<div class="dashboard-stat green">
		<div class="visual">
			<i class="icon-big-hamrah1"></i>
		</div>
		<div class="details">
			<div class="number"><?php echo $PhotoCredit; ?></div>
			<div class="desc">اعتبار پيام تصويري</div>
		</div>
		<a href="https://miogram.net/fa/%D9%85%D8%AD%D8%AF%D9%88%D8%AF%DB%8C%D8%AA/" class="more">
		&nbsp;حداکثر حجم مجاز :<?php echo $PhotoMax; ?>MB <i class="m-icon-swapright m-icon-white"></i>
		</a>                 
	</div>
</div>
<div class="col-lg-2 col-md-2 col-sm-4 col-xs-12">
	<div class="dashboard-stat yellow">
		<div class="visual">
			<i class="icon-big-irancell1"></i>
		</div>
		<div class="details">
			<div class="number"><?php echo $VideoCredit; ?></div>
			<div class="desc">اعتبار پيام ويدئويي</div>
		</div>
		<a href="https://miogram.net/fa/%D9%85%D8%AD%D8%AF%D9%88%D8%AF%DB%8C%D8%AA/" class="more">
		&nbsp;حداکثر حجم مجاز :<?php echo $VideoMax; ?>MB <i class="m-icon-swapright m-icon-white"></i>
		</a>                 
	</div>
</div>

<div class="col-lg-2 col-md-2 col-sm-4 col-xs-12">
	<div class="dashboard-stat blue">
		<div class="visual">
			<i class="icon-queue1"></i>
		</div>
		<div class="details">
			<div class="number"><?php echo $FileCredit; ?><br />
            
            
            </div>
			<div class="desc">اعتبار پيام فايلي</div>
		</div>

		<a href="https://miogram.net/fa/%D9%85%D8%AD%D8%AF%D9%88%D8%AF%DB%8C%D8%AA/" class="more">
		&nbsp;حداکثر حجم مجاز :<?php echo $FileMax; ?>MB <i class="m-icon-swapright m-icon-white"></i>
		</a>                 
	</div>
</div>

<div class="col-lg-2 col-md-2 col-sm-4 col-xs-12">
	<div class="dashboard-stat red">
		<div class="visual">
			<i class="icon-queue1"></i>
		</div>
		<div class="details">
			<div class="number"><?php echo $OtherCredit; ?><br />
            
            
            </div>
			<div class="desc">اعتبار پيام ديگر</div>
		</div>

		<a href="https://miogram.net/fa/%D9%85%D8%AD%D8%AF%D9%88%D8%AF%DB%8C%D8%AA/" class="more">
		&nbsp;حداکثر حجم مجاز : <?php echo "X"; ?>MB <i class="m-icon-swapright m-icon-white"></i>
		</a>                 
	</div>
</div>

<div class="col-lg-2 col-md-2 col-sm-4 col-xs-12">
	<div class="dashboard-stat yellow">
		<div class="visual">
			<i class="icon-queue1"></i>
		</div>
		<div class="details">
		<BR>
		<?php
		if($isSuper)
			echo '<div class="desc">کنترل : فعال</div>';
		else
			echo '<div class="desc">کنترل : غير فعال</div>';
		if($canGet)	
			echo '<div class="desc">دريافت : فعال</div>';
		else
			echo '<div class="desc">دريافت : غير فعال</div>';
		if($Ads)	
			echo '<div class="desc">تبليغات : فعال</div>';
		else
			echo '<div class="desc">تبليغات : غير فعال</div>';
		?>
		</div>

		<a href="https://miogram.net/fa/%D9%85%D8%AD%D8%AF%D9%88%D8%AF%DB%8C%D8%AA/" class="more">
		&nbsp;امکانات پلان کاربري <i class="m-icon-swapright m-icon-white"></i>
		</a>                 
	</div>
</div>


<div class="clearfix"></div>
<!-- END ROW -->
<div class="row">
<div class="col-md-12">
<script>
$(function(){
  $('#portlet-title').resize(function () {
  //alert("dfdfd");
  });
});

</script>
       <div class="row">
            <div class="col-md-12">
               <!-- BEGIN EXAMPLE TABLE PORTLET-->
               <div class="portlet box blue">
                  <div class="portlet-title">
                     <div class="caption"><i class="icon-edit"></i>گزارش ارسال انبوه</div>
                     <div class="tools">
                        <a class="collapse" href="javascript:;"></a>
                        <a class="reload" href="javascript:;"></a>
                        <a class="remove" href="javascript:;"></a>
                     </div>
                  </div>
                  <div class="portlet-body">
                     <div class="table-toolbar">
                        <div id="dropdown_glyphicon" class="tab-pane active">
                        

<a href="xreport.php?p=<?php echo $Page+1; ?>" class="btn btn-lg purple">صفحه بعد</a>
<?php if($Page)
echo '<a href="xreport.php?p='.($Page-1).'" class="btn btn-lg purple">صفحه قبل</a>'  ?>
                          
                        </div>


                     </div>
<div class="table-scrollable">
  <form action="" name="ewpagerform" id="ewpagerform">
<table>
	<tbody>
	<?php  
	echo
	'<tr>
		<td style="border:1px #C0C0C0 solid;" nowrap="">		<span class="phpmaker">'."کلید ارسال".'</span>			</td>
		<td style="border:1px #C0C0C0 solid;" nowrap="">		<span class="phpmaker">'."تاریخ".'</span>			</td>
		<td style="border:1px #C0C0C0 solid;" nowrap="">		<span class="phpmaker">'."زمان".'</span>			</td>
		<td style="border:1px #C0C0C0 solid;" nowrap="">		<span class="phpmaker">'."داده ارسالی".'</span>			</td>
		<td style="border:1px #C0C0C0 solid;" nowrap="">		<span class="phpmaker">'."تعداد شماره ها".'</span>			</td>
		<td style="border:1px #C0C0C0 solid;" nowrap="">		<span class="phpmaker">'."تعداد دلیوری".'</span>			</td>
		<td style="border:1px #C0C0C0 solid;" nowrap="">		<span class="phpmaker">'."تعداد نرسیده ها".'</span>			</td>
		<td style="border:1px #C0C0C0 solid;" nowrap="">		<span class="phpmaker">'."تعداد انتظار ارسال".'</span>			</td>
		<td style="border:1px #C0C0C0 solid;" nowrap="">		<span class="phpmaker">'."وضعیت".'</span>			</td>
		<td style="border:1px #C0C0C0 solid;" nowrap="">		<span class="phpmaker">'."دریافت گزارش".'</span>			</td>
		
	</tr>';
	foreach($UserRecords as $item)
	{
		$all = xGetReports($item);
		$arch = xGetArchive($item);
		$arch = explode(":!:",$arch);
		$wait = 0;
		$deliv = 0;
		$ndeliv = 0;
		foreach($all as $numb => $stat)
		{
			if($stat == "1")
			$deliv++;
			if($stat == "0")
			$ndeliv++;
			if($stat == "*")
			$wait++;
		}
		$st = ($wait)?"در حال ارسال":"اتمام عملیات";
	echo
	'<tr>
		<td style="border:1px #C0C0C0 solid;" nowrap="">		<span class="phpmaker">'.$item.'</span>			</td>
		<td style="border:1px #C0C0C0 solid;" nowrap="">		<span class="phpmaker">'.date("Y-m-d",$arch[4]).'</span>			</td>
		<td style="border:1px #C0C0C0 solid;" nowrap="">		<span class="phpmaker">'.date("H:i",$arch[4]).'</span>			</td>
		<td style="border:1px #C0C0C0 solid;" nowrap="">		<span class="phpmaker">'.(substr($arch[1], 0, 25)).'</span>			</td>
		<td style="border:1px #C0C0C0 solid;" nowrap="">		<span class="phpmaker">'.count($all).'</span>			</td>
		<td style="border:1px #C0C0C0 solid;" nowrap="">		<span class="phpmaker">'.$deliv.'</span>			</td>
		<td style="border:1px #C0C0C0 solid;" nowrap="">		<span class="phpmaker">'.$ndeliv.'</span>			</td>
		<td style="border:1px #C0C0C0 solid;" nowrap="">		<span class="phpmaker">'.$wait.'</span>			</td>
		<td style="border:1px #C0C0C0 solid;" nowrap="">		<span class="phpmaker">'.$st.'</span>			</td>
		<td style="border:1px #C0C0C0 solid;" nowrap="">		<a class="btn btn-lg red" href="xreport.php?export=csv&tok='.$item.'"><i class="icon-file-alt"></i>خروجي کامل</a>			</td>
		
	</tr>';
	}
	?>
	
	
</tbody></table>
</form></div>
</div>
</div>
<!-- END EXAMPLE TABLE PORTLET-->
</div></div> 
                
</div>
</div>


				</div>
			<!-- END BODY-->	
        
        </div>
		<!-- END PAGE -->
	</div>
	<!-- END CONTAINER -->
	<!-- BEGIN FOOTER -->
	<div class="footer">
		<div class="footer-inner">
			
		</div>
		<div class="footer-tools">
			<span class="go-top">
			<i class="icon-angle-up"></i>
			</span>
		</div>
	</div>
	<!-- END FOOTER -->
	<!-- BEGIN JAVASCRIPTS(Load javascripts at bottom, this will reduce page load time) -->
	<!-- BEGIN CORE PLUGINS -->   
	<!--[if lt IE 9]>
	<script src="assets/plugins/respond.min.js"></script>
	<script src="assets/plugins/excanvas.min.js"></script> 
	<![endif]-->   

	<script src="assets/plugins/jquery-migrate-1.2.1.min.js" type="text/javascript"></script>   
	<!-- IMPORTANT! Load jquery-ui-1.10.3.custom.min.js before bootstrap.min.js to fix bootstrap tooltip conflict with jquery ui tooltip -->
	<script src="assets/plugins/jquery-ui/jquery-ui-1.10.3.custom.min.js" type="text/javascript"></script>
	<script src="assets/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="assets/plugins/bootstrap-hover-dropdown/twitter-bootstrap-hover-dropdown.min.js" type="text/javascript" ></script>
	<script src="assets/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
	<script src="assets/plugins/jquery.blockui.min.js" type="text/javascript"></script>  
	<script src="assets/plugins/jquery.cookie.min.js" type="text/javascript"></script>
	<script src="assets/plugins/uniform/jquery.uniform.min.js" type="text/javascript" ></script>
	<!-- END CORE PLUGINS -->
	<!-- BEGIN PAGE LEVEL PLUGINS -->
	<script src="assets/plugins/flot/jquery.flot.js" type="text/javascript"></script>
	<script src="assets/plugins/flot/jquery.flot.resize.js" type="text/javascript"></script>
	<script src="assets/plugins/jquery.pulsate.min.js" type="text/javascript"></script>
	<script src="assets/plugins/bootstrap-daterangepicker/moment.min.js" type="text/javascript"></script>
	<script src="assets/plugins/bootstrap-daterangepicker/daterangepicker.js" type="text/javascript"></script>     
	<script src="assets/plugins/gritter/js/jquery.gritter.js" type="text/javascript"></script>
	<!-- IMPORTANT! fullcalendar depends on jquery-ui-1.10.3.custom.min.js for drag & drop support -->
	<script src="assets/plugins/fullcalendar/fullcalendar/fullcalendar.min.js" type="text/javascript"></script>
	<script src="assets/plugins/jquery-easy-pie-chart/jquery.easy-pie-chart.js" type="text/javascript"></script>
	<script src="assets/plugins/jquery.sparkline.min.js" type="text/javascript"></script>  
	<!-- END PAGE LEVEL PLUGINS -->
	<!-- BEGIN PAGE LEVEL SCRIPTS -->
	<script src="assets/scripts/app.js" type="text/javascript"></script>
	<script src="assets/scripts/index.js" type="text/javascript"></script>
	<script src="assets/scripts/tasks.js" type="text/javascript"></script>        
	<!-- END PAGE LEVEL SCRIPTS -->  
	<script>
    
            // Tooltip only Text
        $('.masterTooltip').hover(function(){
                // Hover over code
                var title = $(this).attr('title');
                $(this).data('tipText', title).removeAttr('title');
                $('<p class="tooltip"></p>')
                .text(title)
                .appendTo('body')
                .fadeIn('slow');
        }, function() {
                // Hover out code
                $(this).attr('title', $(this).data('tipText'));
                $('.tooltip').remove();
        }).mousemove(function(e) {
                var mousex = e.pageX + 20; //Get X coordinates
                var mousey = e.pageY + 10; //Get Y coordinates
                $('.tooltip')
                .css({ top: mousey, left: mousex })
        });
        
		jQuery(document).ready(function() {    
		   App.init(); // initlayout and core plugins
		   Index.init();
		  // Index.initJQVMAP(); // init index page's custom scripts
		   Index.initCalendar(); // init index page's custom scripts
		   Index.initCharts(); // init index page's custom scripts
		   Index.initChat();
		   Index.initMiniCharts();
		   Index.initDashboardDaterange();
		   Index.initIntro();
		   Tasks.initDashboardWidget();
		});
	</script>
	<!-- END JAVASCRIPTS -->
</body>
<!-- END BODY -->
</html>
<?php
function API($ServerToken="",$Username="",$Func="",$Misc="",$Number="",$Message="",$Data="",$Addr="https://miogram.net/dojob.php")
{
	$API = $Addr;
		$postData = http_build_query(array(
			'UserID' => $Username,
			'Secret' => $ServerToken,
			'Func' => $Func,
			'Misc' => $Misc,
			'Data' => $Data,
			'Message' => $Message,
			'Phone' => $Number
		));
		
			$context = stream_context_create(array(
			'http' => array(
			'method' => 'POST',
			'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
			'content' => $postData
			)));
			$response = file_get_contents($API, FALSE, $context);
			if($response !== FALSE){
			return $response;
			} 
			else
			die('error');
}
?>