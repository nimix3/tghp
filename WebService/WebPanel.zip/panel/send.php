<?php
require( '/home/miogram/public_html/fa/wp-load.php' );
require( '/home/miogram/public_html/fa/wp-blog-header.php' );
require("../../config.php");
if (!is_user_logged_in())
	header("Location: https://miogram.net/fa/wp-login.php?action=login"); 
$current_user = wp_get_current_user();
$Username = $current_user->user_login;
$db = mysqli_connect($dbserver, $dbuser, $dbpass, $dbname); // Connect to Database
if (!$db) {
die("Connection failed: " . mysqli_connect_error()); }
@ mysqli_set_charset($db, "utf8");
$sql = "SELECT Secret,robot,Mlimit FROM $table WHERE Username = '$Username' LIMIT 1";
@ $result = mysqli_query($db,$sql);
if(mysqli_num_rows($result) <= 0)
	header("Location: ".get_home_url());
$data = mysqli_fetch_assoc($result);
$Secret = $data['Secret'];
$Robot = $data['robot'];
$MsgMax = $data['Mlimit'];
if (strpos($Robot, ',') !== false)
	$Robot = explode(",",$Robot);
else $Robot = array($Robot);	
mysqli_close($db);
//=====================================================================//
if ($_SERVER['REQUEST_METHOD'] === 'POST')
{
	if($_POST['Type'] == "-1")
		exit("نوع پیام مشخص نشده است");
$phone = "";
@ $phone = $_POST['Number'];
@ $Message = $_POST['Message'];
@ $GPName = $_POST['Subject'];
@ $GPName = str_replace(PHP_EOL,"",$GPName);
@ $Func = $_POST['Type'];
@ $File = $_FILES['File']['tmp_name'];
@ $Data = base64_encode(file_get_contents($File));
@ $Type= pathinfo($_FILES['File']['name'], PATHINFO_EXTENSION);
//@ $Type=  pathinfo($File, PATHINFO_EXTENSION);
if(!isset($GPName) or empty($GPName))
	$GPName = "کاربر گرامی::";
@ $phone = iconv("UTF-8", "ASCII", $phone);

if (strpos($phone, '\n\r') !== false)
{
$phone = str_replace("\n\r",",",$phone);
$phone = explode(",",$phone);
$phone = array_unique($phone);
$phone = implode(",",$phone);
}
else if (strpos($phone, PHP_EOL) !== false)
{
$phone = str_replace(PHP_EOL,",",$phone);
$phone = explode(",",$phone);
$phone = array_unique($phone);
$phone = implode(",",$phone);
}
else if (strpos($phone, '<br>') !== false)
{
$phone = str_replace('<br>',",",$phone);
$phone = explode(",",$phone);
$phone = array_unique($phone);
$phone = implode(",",$phone);
}
else if (strpos($phone, '-') !== false)
{
$phone = str_replace("-",",",$phone);
$phone = explode(",",$phone);
$phone = array_unique($phone);
$phone = implode(",",$phone);
}
else if (strpos($phone, ' ') !== false)
{
$phone = str_replace(" ",",",$phone);
$phone = explode(",",$phone);
$phone = array_unique($phone);
$phone = implode(",",$phone);
}
$Robot = $_POST['Robot'];
$phone = preg_replace('/\s+/', '', $phone);
//var_dump($Secret,$Func,$Type,$phone,$Message,$Data,$Robot);
//die();
@ API($Secret,'',$Func,$Type,$phone,$GPName."::".$Message,$Data,$Robot);
}
?>
<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>سیستم ارسال پیام به تلگرام</title>
        <link rel="stylesheet" href="css/style.css">
		<link rel="stylesheet" type="text/css" href="css/style1.css" />
		<script src="js/modernizr.custom.63321.js"></script>
  </head>
  <body>
    <div class="wrapper">
	<div class="container">
		<h1>Telegram Send Message</h1>
		<h4 style='font-family: "tahoma", Georgia, Serif;'>سیستم ارسال پیام به تلگرام</h4>
		<form id="form" method="post" action="send.php" enctype="multipart/form-data" accept-charset="UTF-8" class="form" >
			<!-- <input name="phone" type="textarea" style='font-family: "tahoma", Georgia, Serif;' placeholder="شماره  تماس"> -->
			<section style="margin: 0 auto;" class="main clearfix">
				<div class="fleft">
					<select style='font-family: "tahoma", Georgia, Serif;' id="cd-dropdown" name="Type" class="cd-select">
						<option value="-1" selected>نوع پیام</option>
						<option value="SendMessageSmart" class="icon-diamond">پیام متنی</option>
						<option value="SendMessageSmart" class="icon-firefox">پیام تصویری</option>
						<option value="SendMessageSmart" class="icon-rocket">پیام ویدئویی</option>
						<option value="SendMessageSmart" class="icon-android">پیام فایلی</option>
					</select>
				</div>
				<div class="fleft">
					<select style='font-family: "tahoma", Georgia, Serif;' id="cd-dropdown" name="Robot" class="cd-select">
						<option value="-1" selected>نوع پیام رسان</option>
						<?php foreach($Robot as $robo) echo '<option value="'.$robo.'" class="icon-android">'.$robo.'</option>'; ?>
					</select>
				</div>
			</section>
			<h4 style='font-family: "tahoma", Georgia, Serif;'>شماره ها</h4><p id="numb">0</p>
			</BR>
			<textarea name="Number" id="number" placeholder="شماره تلفن" value="+989130000000" rows="5" cols="50"></textarea>
			</BR></BR>
					<h4 style='font-family: "tahoma", Georgia, Serif;'>عنوان پیام</h4><p id="count">0</p>
			</BR>
			<textarea name="Subject" id="subject" maxlength="25" placeholder="عنوان پیام" rows="1" cols="50"></textarea>
			</BR>
			<h4 style='font-family: "tahoma", Georgia, Serif;'>متن پیام</h4><p id="count">0</p>
			</BR>
			<textarea name="Message" id="message" maxlength="<?php echo $MsgMax; ?>" placeholder="متن پیام" rows="5" cols="50"></textarea>
			</BR></BR>
			<h4 style='font-family: "tahoma", Georgia, Serif;'>فایل</h4>
			</BR>
			<input type="file" name="File">
			</BR></BR>
			
			<button type="submit" onclick="document.getElementById('form').submit();" id="login-button">ارسال</button>
			</BR></BR>
		</form>
	</div>
	<ul class="bg-bubbles">
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
	</ul>
</div>
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
		<script type="text/javascript" src="js/jquery.dropdown.js"></script>
		<script type="text/javascript">
			$("#message").keyup(function(){
  $("#count").text(<?php echo $MsgMax; ?> -$(this).val().length);
  if(<?php echo $MsgMax; ?> -$(this).val().length < 0)
  $('#message').attr("disabled", "disabled");
});
			$("#number").keyup(function(){
  $("#numb").text($(this).val().split(/\r|\r\n|\n/).length);
});
			$( function() {
				
				$( '#cd-dropdown' ).dropdown( {
					gutter : 5
				} );

			});

		</script>
        <script src="js/index.js"></script>
  </body>
</html>
<?php
function API($ServerToken="",$Username="",$Func="",$Misc="",$Number="",$Message="",$Data="",$Robot="",$Addr="https://miogram.net/dojob.php")
{
	$API = $Addr;
		$postData = http_build_query(array(
			'UserID' => $Username,
			'Secret' => $ServerToken,
			'Func' => $Func,
			'Misc' => $Misc,
			'Data' => $Data,
			'Message' => $Message,
			'Robot' => $Robot,
			'Phone' => $Number
		));
		
			$context = stream_context_create(array(
			'http' => array(
			'method' => 'POST',
			'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
			'content' => $postData
			)));
			$response = file_get_contents($API, FALSE, $context);
			if($response !== FALSE){
			return $response;
			} 
			else;
			//die('error');
}
?>