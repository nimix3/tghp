<?php
require( '/home/miogram/public_html/fa/wp-load.php' );
require( '/home/miogram/public_html/fa/wp-blog-header.php' );
require("../../config.php");
require("../../smart.php");
$DBFILE = "userdata2.db";
if (!is_user_logged_in())
	header("Location: https://miogram.net/fa/wp-login.php?action=login"); 
$current_user = wp_get_current_user();
$Username = $current_user->user_login;
$db = mysqli_connect($dbserver, $dbuser, $dbpass, $dbname); // Connect to Database
if (!$db) {
die("Connection failed: " . mysqli_connect_error()); }
@ mysqli_set_charset($db, "utf8");
$sql = "SELECT Secret,robot,Mlimit FROM $table WHERE Username = '$Username' LIMIT 1";
@ $result = mysqli_query($db,$sql);
if(mysqli_num_rows($result) <= 0)
	header("Location: ".get_home_url());
$data = mysqli_fetch_assoc($result);
$Secret = $data['Secret'];
$Robot = $data['robot'];
$MsgMax = $data['Mlimit'];
if (strpos($Robot, ',') !== false)
	$Robot = explode(",",$Robot);
else $Robot = array($Robot);	
mysqli_close($db);
//=====================================================================//
if ($_SERVER['REQUEST_METHOD'] === 'POST')
{
	if($_POST['Type'] == "-1")
		exit();
$phone = "";
@ $phonex = $_POST['Number'];
@ $Message = $_POST['Subject']."%%".$_POST['Message'];
@ $Func = $_POST['Type'];
@ $File = $_FILES['File']['tmp_name'];
@ $Data = base64_encode(file_get_contents($File));
@ $Type= pathinfo($_FILES['File']['name'], PATHINFO_EXTENSION);
//@ $Type=  pathinfo($File, PATHINFO_EXTENSION);
$data = file_get_contents($File);

if(strpos($data,PHP_EOL) !== false)
$phone = explode("\n",$data);
else
$phone = explode(",",$data);
	 
$phone = array_merge(PhArr($phonex) , $phone);
$d = array();

foreach($phone  as $t)
{
$t = str_replace(PHP_EOL,'',$t);
$t = preg_replace('/\s+/','',$t);
$t = PhoneCorr($t);
$d[] = $t;
}
if(!isset($_POST['Robot']) or empty($_POST['Robot']))
{
	$Roboot = implode(",",$Robot);
}
else
	$Roboot = $_POST['Robot'];

$tok = xSmartSend($Secret,implode(",",$d),$Message,$Roboot);
	 $CACHE = read_ini_file($DBFILE);
	 $CACHE["$tok"] = $Username;
	 write_ini_file($CACHE, $DBFILE);
}
?>
<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>سیستم ارسال پیام به تلگرام</title>
        <link rel="stylesheet" href="css/style.css">
		<link rel="stylesheet" type="text/css" href="css/style1.css" />
		<script src="js/modernizr.custom.63321.js"></script>
  </head>
  <body>
    <div class="wrapper">
	<div class="container">
		<h1>Telegram Send Smart Message</h1>
		<h4 style='font-family: "tahoma", Georgia, Serif;'>سیستم ارسال هوشمند پیام به تلگرام</h4>
		<form id="form" method="post" action="xsend.php" enctype="multipart/form-data" accept-charset="UTF-8" class="form" >
			This Features is Disabled Now , Use Bulk Send Instead.
		</form>
	</div>
	<ul class="bg-bubbles">
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
	</ul>
</div>
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
		<script type="text/javascript" src="js/jquery.dropdown.js"></script>
		<script type="text/javascript">
			$("#message").keyup(function(){
  $("#count").text(<?php echo $MsgMax; ?> -$(this).val().length);
  if(<?php echo $MsgMax; ?> -$(this).val().length < 0)
  $('#message').attr("disabled", "disabled");
});
			$("#number").keyup(function(){
  $("#numb").text($(this).val().split(/\r|\r\n|\n/).length);
});
			$( function() {
				
				$( '#cd-dropdown' ).dropdown( {
					gutter : 5
				} );

			});

		</script>
        <script src="js/index.js"></script>
  </body>
</html>
<?php
function API($ServerToken="",$Username="",$Func="",$Misc="",$Number="",$Message="",$Data="",$Robot="",$Addr="https://miogram.net/dojob.php")
{
	$API = $Addr;
		$postData = http_build_query(array(
			'UserID' => $Username,
			'Secret' => $ServerToken,
			'Func' => $Func,
			'Misc' => $Misc,
			'Data' => $Data,
			'Message' => $Message,
			'Robot' => $Robot,
			'Phone' => $Number
		));
		
			$context = stream_context_create(array(
			'http' => array(
			'method' => 'POST',
			'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
			'content' => $postData
			)));
			$response = file_get_contents($API, FALSE, $context);
			if($response !== FALSE){
			return $response;
			} 
			else;
			//die('error');
}
function PhoneCorr($phone)
{
	@ $phone = iconv("UTF-8", "ASCII", $phone);
$phone = preg_replace('/\s+/', '', $phone);
if (substr($phone, 0, 2) === "98")
{
	$phone = "+98".substr($phone, 2, 10);
}
else if (substr($phone, 0, 2) === "00")
{
	$phone = "+98".substr($phone, 4, 10);
}
else if (substr($phone, 0, 2) === "09")
{
	$phone = "+98".substr($phone, 1, 10);
}
else if (substr($phone, 0, 1) === "9" and substr($phone, 0, 2) !== "98")
{
	$phone = "+98".$phone;
}
return $phone;
}

function PhArr($phone)
{
	if (strpos($phone, '\n\r') !== false)
{
$phone = str_replace("\n\r",",",$phone);
$phone = explode(",",$phone);
$phone = array_unique($phone);
$phone = implode(",",$phone);
}
else if (strpos($phone, PHP_EOL) !== false)
{
$phone = str_replace(PHP_EOL,",",$phone);
$phone = explode(",",$phone);
$phone = array_unique($phone);
$phone = implode(",",$phone);
}
else if (strpos($phone, '<br>') !== false)
{
$phone = str_replace('<br>',",",$phone);
$phone = explode(",",$phone);
$phone = array_unique($phone);
$phone = implode(",",$phone);
}
else if (strpos($phone, '-') !== false)
{
$phone = str_replace("-",",",$phone);
$phone = explode(",",$phone);
$phone = array_unique($phone);
$phone = implode(",",$phone);
}
else if (strpos($phone, ' ') !== false)
{
$phone = str_replace(" ",",",$phone);
$phone = explode(",",$phone);
$phone = array_unique($phone);
$phone = implode(",",$phone);
}
return explode(",",$phone);
}
?>