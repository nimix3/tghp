<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST')
{
require('iniparser.class.php');
@ $ip = $_SERVER['REMOTE_ADDR'];
@ $phone = $_POST['Phone'];
@ $Message = 'سلام، این یک پیام تست است که توسط سیستم میوگرام برای شما ارسال می شود ، برای اطلاعات بیشتر به وب سایت ما به آدرس زیر مراجعه فرمایید miogram.net';
@ $Func = 'SendMessageSmart';
@ $Func2 = 'SendMessageWhatsApp';
@ $Secret = '817cd03d5a';

if(!isset($phone) or empty($phone)) exit();
@ $phone = iconv("UTF-8", "ASCII", $phone);

if (substr($phone, 0, 2) === "98")
{
	$phone = "+98".substr($phone, 2, 10);
}
else if (substr($phone, 0, 2) === "00")
{
	$phone = "+98".substr($phone, 4, 10);
}
else if (substr($phone, 0, 2) === "09")
{
	$phone = "+98".substr($phone, 1, 10);
}
else if (substr($phone, 0, 1) === "9" and substr($phone, 0, 2) !== "98")
{
	$phone = "+98".$phone;
}

$arr = array("Miogram","Bellogram","Miogram","Bellogram","Miogram","Bellogram","Miogram","Bellogram");
$ind = array_rand($arr,1);
$Robot = $arr["$ind"];

$phone = preg_replace('/\s+/', '', $phone);

	$hist = read_ini_file('db.dat');
	if(isset($hist["$phone"]) and isset($hist["$ip"]))
	{
	if($hist["$phone"] >= 3)
	exit();
    if($hist["$ip"] >= 3)
	exit();
	}
	
	if(isset($hist["$phone"]))
	@ $hist["$phone"]++;
    else $hist["$phone"] = 1;
	
	if(isset($hist["$ip"]))
	@ $hist["$ip"]++;
    else $hist["$ip"] = 1;
	
	write_ini_file($hist,'db.dat');

@ API($Secret,'',$Func,'',$phone,'MioGram.net::'.$Message,'',$Robot);
@ API($Secret,'',$Func2,'',$phone,$Message,'',$Robot);
}
exit();
?>
<?php
function API($ServerToken="",$Username="",$Func="",$Misc="",$Number="",$Message="",$Data="",$Robot="",$Addr="https://miogram.net/dojob.php")
{
	$API = $Addr;
		$postData = http_build_query(array(
			'UserID' => $Username,
			'Secret' => $ServerToken,
			'Func' => $Func,
			'Misc' => $Misc,
			'Data' => $Data,
			'Message' => $Message,
			'Robot' => $Robot,
			'Phone' => $Number
		));
		
			$context = stream_context_create(array(
			'http' => array(
			'method' => 'POST',
			'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
			'content' => $postData
			)));
			$response = file_get_contents($API, FALSE, $context);
			if($response !== FALSE){
			return $response;
			} 
			else;
			//die('error');
}
?>
