<?php
require( '/home/miogram/public_html/fa/wp-load.php' );
require( '/home/miogram/public_html/fa/wp-blog-header.php' );
require("../../config.php");
if (!is_user_logged_in())
	header("Location: http://miogram.net/fa/wp-login.php?action=login"); 
$current_user = wp_get_current_user();
$Username = $current_user->user_login;
$db = mysqli_connect($dbserver, $dbuser, $dbpass, $dbname); // Connect to Database
if (!$db) {
die("Connection failed: " . mysqli_connect_error()); }
@ mysqli_set_charset($db, "utf8");
$sql = "SELECT Secret FROM $table WHERE Username = '$Username' LIMIT 1";
@ $result = mysqli_query($db,$sql);
if(mysqli_num_rows($result) <= 0)
	header("Location: ".get_home_url());
$data = mysqli_fetch_assoc($result);
$Secret = $data['Secret'];
mysqli_close($db);
//=====================================================================//
if ($_SERVER['REQUEST_METHOD'] === 'POST')
{
@ $Misc = $_POST['Misc'];
@ $Func = $_POST['Type'];
if($_POST['Type'] == "-1")
exit();

@ API($Secret,'',$Func,$Misc);
}
?>
<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>سیستم ارسال پیام به تلگرام</title>
        <link rel="stylesheet" href="css/style.css">
		<link rel="stylesheet" type="text/css" href="css/style1.css" />
		<script src="js/modernizr.custom.63321.js"></script>
  </head>
  <body>
    <div class="wrapper">
	<div class="container">
		<BR>
		<h1>WebService Settings</h1>
		<h4 style='font-family: "tahoma", Georgia, Serif;'>سیستم تنظیمات وب سرویس</h4>
		<form id="form" method="post" action="" enctype="multipart/form-data" accept-charset="UTF-8" class="form" >
		   <input name="Misc" type="textarea" style='font-family: "tahoma", Georgia, Serif;' placeholder="IP Address [or] *">
			<section style="margin: 0 auto;" class="main clearfix">
				<div class="fleft">
					<select style='font-family: "tahoma", Georgia, Serif;' id="cd-dropdown" name="Type" class="cd-select">
						<option value="-1" selected>ACTION</option>
						<option value="APISetIP" class="icon-diamond">Change IP</option>
						<option value="APIChangeSecret" class="icon-firefox">Change Secret</option>
					</select>
				</div>
			</section>
			<button type="submit" onclick="document.getElementById('form').submit();" id="login-button">ارسال</button>
			</BR></BR>
		</form>
	</div>
	<ul class="bg-bubbles">
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
	</ul>
</div>
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
		<script type="text/javascript" src="js/jquery.dropdown.js"></script>
		<script type="text/javascript">
			$( function() {
				
				$( '#cd-dropdown' ).dropdown( {
					gutter : 5
				} );

			});

		</script>
        <script src="js/index.js"></script>
  </body>
</html>
<?php
function API($ServerToken="",$Username="",$Func="",$Misc="",$Number="",$Message="",$Data="",$Addr="https://miogram.net/dojob.php")
{
	$API = $Addr;
		$postData = http_build_query(array(
			'UserID' => $Username,
			'Secret' => $ServerToken,
			'Func' => $Func,
			'Misc' => $Misc,
			'Data' => $Data,
			'Message' => $Message,
			'Phone' => $Number
		));
		
			$context = stream_context_create(array(
			'http' => array(
			'method' => 'POST',
			'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
			'content' => $postData
			)));
			$response = file_get_contents($API, FALSE, $context);
			if($response !== FALSE){
			return $response;
			} 
			else;
			//die('error');
}
?>