﻿function ShowDetails(obj)
{
    current = (document.getElementById(obj).style.display == "none") ? "block" : "none";
    document.getElementById(obj).style.display = current;
}// پیام هشدار
function numberWithCommas(n) {
    var parts=n.toString().split(".");
    return parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",") + (parts[1] ? "." + parts[1] : "");
}
function alerts(message) {
    jAlert(message);
}

function msg(title, message, delay) {
    $.growlUI(title, message, delay);
}

// سوال تایید
function confirms(message) {
    //    var retval = false;
    //    jConfirm(message, 'تاییدیه سامانه', function(r) {
    //        retval = r;
    //    });
    //    return false;

    return confirm(message);

}

// باز و بسته کردن تگ دلخواه
function togglerbox(togglerId) {
    //alert("ff");
    jQuery('#' + togglerId).toggle(500);
}

// باز  کردن تگ دلخواه
function openMe(openId) {
    $('#' + openId).show(500);
}

//  بستن  تگ دلخواه
function closeMe(closeId) {
    $('#' + closeId).hide(500);
}

function chk(checkboxId, tagId) {

    if ($("#" + checkboxId).is(":checked")) {
        openMe(tagId);

    }
    else {
        closeMe(tagId);
    }

}

// محاسبه تعداد کاراکتر های باقیمانده پیامک
var smsCount = 1;
function smsLeftChar(txtSms, lblLeft, lblSms, lblMax, txtSign) {

    var smsBody = $('#' + txtSms).val(); //+ $('#' + txtSign).val();

    var isPersian = isUnicode(smsBody);
    var maxLen = 0;
    var msgLen = smsBody.length;
    var currentLen = msgLen;

    var charLeft = 0;

    if (isPersian) {
        maxLen = 70;
        $('#' + txtSms).css({ 'direction': 'rtl' });
    }
    else {
        maxLen = 160;
        $('#' + txtSms).css({ 'direction': 'ltr' });
    }

    if (currentLen > maxLen) {

        while (msgLen > maxLen) {
            msgLen -= maxLen;
        }

        if ((msgLen % maxLen) != 0) {
            smsCount = parseInt(Math.floor(currentLen / maxLen)) + 1;

        }
        else {
            smsCount = parseInt(currentLen / maxLen);
        }

    }
    else {
        smsCount = 1;
    }

    $('#' + lblLeft).html(maxLen - msgLen);
    $('#' + lblSms).html(smsCount);
    $('#' + lblMax).html(maxLen);

}

function checkSMSLength(textarea, counterSpan, partSpan, maxSpan, def) {


    var text = document.getElementById(textarea).value;
    var ucs2 = text.search(/[^\x00-\x7E]/) != -1
    if (!ucs2) text = text.replace(/([[\]{}~^|\\])/g, "\\$1");
    var unitLength = ucs2 ? 5000 : 5000;
    var msgLen = 0;
    msgLen = document.getElementById(textarea).value.length; //+docu def;

    document.getElementById(textarea).style.direction = text.match(/^[^a-z]*[^\x00-\x7E]/ig) ? 'rtl' : 'ltr';

//    if (msgLen > unitLength) {
//        if (ucs2) unitLength = unitLength - 3;
//        else unitLength = unitLength - 7;
//    }
//
    var count = Math.max(Math.ceil(msgLen / unitLength), 1);

    document.getElementById(maxSpan).innerHTML = unitLength;
    document.getElementById(counterSpan).innerHTML = (unitLength * count - msgLen);
    document.getElementById(partSpan).innerHTML = count;


}


// تشخیص یونیکد بودن متن
function isUnicode(str) {
    var letters = [];
    for (var i = 1; i <= str.length; i++) {
        letters[i] = str.substring((i - 1), i);
        if (letters[i].charCodeAt() > 255) { return true; }
    }
    return false;
}

// انتخاب/حذف انتخاب همه سطر ها

var checkflag = "false";
function select_deselectAll() {

    if (chk_Array_IDs != null) {
        if (checkflag == "false") {
            for (i = 0; i < chk_Array_IDs.length; i++) {
                var ref_chk = document.getElementById(chk_Array_IDs[i]);
                if (ref_chk != null)

                    ref_chk.checked = true;
            }
            checkflag = "true";

        }
        else {
            for (i = 0; i < chk_Array_IDs.length; i++) {
                var ref_chk = document.getElementById(chk_Array_IDs[i]);
                if (ref_chk != null)
                    ref_chk.checked = false;
            }
            checkflag = "false";
        }
    }
}

// انتخاب همه سطر ها
function selectAll() {

    if (chk_Array_IDs != null) {

        for (i = 0; i < chk_Array_IDs.length; i++) {
            var ref_chk = document.getElementById(chk_Array_IDs[i]);
            if (ref_chk != null)

                ref_chk.checked = true;
        }

    }
}

// حذف انتخاب همه سطر ها
function deSelectAll() {

    if (chk_Array_IDs != null) {

        for (i = 0; i < chk_Array_IDs.length; i++) {
            var ref_chk = document.getElementById(chk_Array_IDs[i]);
            if (ref_chk != null)

                ref_chk.checked = false;
        }

    }
}


//  انتخاب معکوس سطر ها
function inSelectAll() {

    if (chk_Array_IDs != null) {

        for (i = 0; i < chk_Array_IDs.length; i++) {
            var ref_chk = document.getElementById(chk_Array_IDs[i]);
            if (ref_chk != null)
                if (ref_chk.checked == false)
                    ref_chk.checked = true;
                else
                    ref_chk.checked = false;
        }

    }
}

function select_deselect(chk_Array, chk) {


    if (chk_Array != null) {

        for (i = 0; i < chk_Array.length; i++) {
            var ref_chk = document.getElementById(chk_Array[i]);
            if (ref_chk != null)
                ref_chk.checked = chk;
        }


    }
}

// قرار دادن کاما در فیلد قیمت
function moneyCommaSep(id) {
    var ctrl = document.getElementById(id);
    if (ctrl != null) {
        var separator = ",";
        var int = ctrl.value.replace(new RegExp(separator, "g"), "");
        var regexp = new RegExp("\\B(\\d{3})(" + separator + "|$)");
        do {
            int = int.replace(regexp, separator + "$1");
        }
        while (int.search(regexp) >= 0)
        ctrl.value = int;
    }
}

// حذف کاما
function removeComma(id) {
    var ctrl = document.getElementById(id);
    var separator = ",";
    ctrl.value = ctrl.value.replace(new RegExp(separator, "g"), "");
}


function GetParentIfExists(wnd) {
    var wndOpener = wnd.parent;
    if (!wndOpener) wndOpener = wnd;
    return wndOpener;
}
function OpenPopupWindow(childURL, childName, childFeatures) {
    var wndOpener = GetParentIfExists(window);
    var wndChild;
    wndChild = wndOpener.open(childURL, childName, childFeatures);
    if (wndChild != null) {
        if (g_JS_isWin || !g_JS_isIE)
            wndChild.focus();
    }
}

function popMe(Url, width, height) {
    var wndOpener = GetParentIfExists(window);
    var wndChild;
    wndChild = wndOpener.open(Url, 'X625', 'width=' + width + ',height=' + height + ',top=20,left=100,toolbar=no,scrollbars=yes,resizable=yes');
}

function ajax(myUrl, myData) {
    $.ajax({
        type: "GET",
        url: myUrl,
        data: myData,
        success: function (content) {
            return content;
        },
        error: function () {
            alert('error');
        }
    });
}

function checkSelect() {
    var count = 0;
    if (chk_Array_IDs != null) {

        for (i = 0; i < chk_Array_IDs.length; i++) {
            var ref_chk = document.getElementById(chk_Array_IDs[i]);
            if (ref_chk != null && ref_chk.checked == true) {
                count++;
            }
        }
    }
    if (count == 0) {
        alert("هیچ رکوردی انتخاب نشده است");
        return false;
    }
    else {
        return true;
    }
}

function checkGroup() {
    if (Page_ClientValidate()) {
        var count = 0;
        var checked = 0;
        if (group_Array_IDs != null) {

            for (i = 0; i < group_Array_IDs.length; i++) {
                var ref_chk = document.getElementById(group_Array_IDs[i]);
                if (ref_chk != null && ref_chk.checked == true) {
                    checked++;
                }
                count++;
            }
        }
        if (count == 0) {
            alert("هنوز هیچ گروهی تعریف نشده است\nاز طریق مدیریت گروه ها گروه ایجاد نمایید");
            return false;
        }
        else {
            if (checked == 0) {
                alert("هیچ گروه مخاطبی  انتخاب نشده است");
                return false;
            }
            else {
                return true;
            }
        }
    }
}



function printMe(id) {

    $('#' + id).printElement();

}

function hideMe() {
    parent.$.facebox.close();

}

function clickButton(e, buttonid) {

    var evt = e ? e : window.event;

    var bt = document.getElementById(buttonid);

    if (bt) {

        if (evt.keyCode == 13) {

            bt.click();

            return false;

        }

    }

}



 function AddCombo(destination,task,id,selected)
{

val=document.getElementById(id).value;
document.getElementById(destination+"_div").innerHTML = 'در حال بارگذاری ....';
//alert(val);student_div
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
	//	alert(xmlhttp.responseText);
  //  alert(document.getElementById("subcombonew").innerHTML);
    document.getElementById(destination+"_div").innerHTML = xmlhttp.responseText;
  //  data=xmlhttp.responseText;
    }
  }

xmlhttp.open("GET","combo.php?task="+task+"&val="+val+"&selected="+selected,true);
  xmlhttp.setRequestHeader('Content-Type', 'text/html; charset=utf-8');
xmlhttp.send();
}




 function AddCombo2(destination,task,id,selected)
{

val=document.getElementById(id).value;
document.getElementById(destination+"_div").innerHTML = 'در حال بارگذاری ....';
//alert(val);student_div
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
	//	alert(xmlhttp.responseText);
  //  alert(document.getElementById("subcombonew").innerHTML);
    document.getElementById(destination+"_div").innerHTML = xmlhttp.responseText;
  //  data=xmlhttp.responseText;
    }
  }
 
xmlhttp.open("GET","combo2.php?task="+task+"&val="+val+"&selected="+selected,true);
xmlhttp.setRequestHeader('Content-Type', 'text/html; charset=utf-8');
xmlhttp.send();
}

 function AddComboByValue(destination,task,id,selected)
{

val=id;
//alert(val);student_div
document.getElementById(destination+"_div").innerHTML = 'در حال بارگذاری ....';
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
	//	alert(xmlhttp.responseText);
  //  alert(document.getElementById("subcombonew").innerHTML);
    document.getElementById(destination+"_div").innerHTML = xmlhttp.responseText;
  //  data=xmlhttp.responseText;
    }
  }
xmlhttp.setRequestHeader('Content-Type', 'text/html; charset=utf-8');
xmlhttp.open("GET","combo.php?task="+task+"&val="+val+"&selected="+selected,true);
xmlhttp.send();
}




function IsNumeric(n) {
  return !isNaN(parseFloat(n)) && isFinite(n);
}


function openTree(groupId, address) {	
    var cont = $("#groupName_" + groupId).html();
    if ($("#nodes_" + groupId).html() == '') {
    	$('#table_overlayer').show();
        $("#groupName_" + groupId).html('لطفا صبر کنید...');
        $.ajax({
            type: "POST",
            url: address,
            data: "id=" + groupId,
            success: function (content) {
                $("#groupName_" + groupId).html(cont);
                $("#plus_" + groupId).toggleClass("min");
                $("#nodes_" + groupId).html(content);
                $("#nodes_" + groupId).show(500);
                $('#table_overlayer').hide();
            },
            error: function () {
                alert('error');
            }
        });
    }
    else {
		$('#table_overlayer').show();
        $("#plus_" + groupId).toggleClass("min");
        $("#nodes_" + groupId).toggle(500);
		$('#table_overlayer').hide();
    }

}

function checkTree(groupId) {
    var chk = "#nodes_" + groupId;
    $(chk + " input").each(function (i) {
        $(this).attr("checked", $("#chkGroup_" + groupId).attr("checked"));
    });

}
function uncheckRadio(branchId,address){
	
	if($('#chkGroup_'+branchId).attr('checked')==true){
		$('#chkGroup_'+branchId).attr('checked',false);
			$.ajax({
		        type: "GET",
		        url: address,
		        data: "branchId=" + branchId,
		        success: function (content) {
		        	var str = content;
			        var items = str.split(";");
		        	var lastBranchID = $("#hSelectedRadio").val();
		        	var lastNumberHCount = parseInt($("#hNumberHCount").val());
		        	var lastNumberICount = parseInt($("#hNumberICount").val());
		            $(".numberHCount").html(lastNumberHCount-parseInt(items[0]));
		            $(".numberICount").html(lastNumberICount-parseInt(items[1]));
		            $("#hNumberHCount").val(lastNumberHCount-parseInt(items[0]));
		            $("#hNumberICount").val(lastNumberICount-parseInt(items[1]));
		            var limit = parseInt($('#hcheckLimit').val());
					$('#hcheckLimit').val(--limit);
					var newBranchIds = lastBranchID.replace(branchId+",", "");
					$("#hSelectedRadio").val(newBranchIds);
		        },
		        error: function (err) {
		            alert(err);
		        }
		    });
	}
	
	
}
function checkRadio(branchId,object,address) {
	$('#table_overlayer').show();
	var status = object.attr('checked');
	if(status == true){
		var limit = parseInt($('#hcheckLimit').val());
		if(limit<3){
			$('#hcheckLimit').val(++limit);
			$("#numberCount_div").show(500);
			$(".numberHCount").html(' در حال بارگذاری شاخه ها ...');
			$(".numberICount").html(' در حال بارگذاری شاخه ها ...');	
		    $.ajax({
		        type: "GET",
		        url: address,
		        data: "branchId=" + branchId,
		        success: function (content) {
		        	var str = content;
		        	var items = str.split(";");
		        	var lastBranchID = $("#hSelectedRadio").val();
		        	var lastNumberHCount = parseInt($("#hNumberHCount").val());
		        	var lastNumberICount = parseInt($("#hNumberICount").val());
		            $(".numberHCount").html(lastNumberHCount+parseInt(items[0]));
		            $(".numberICount").html(lastNumberICount+parseInt(items[1]));
		            $("#hSelectedRadio").val(lastBranchID+branchId+",");
		            $("#hNumberHCount").val(lastNumberHCount+parseInt(items[0]));
		            $("#hNumberICount").val(lastNumberICount+parseInt(items[1]));
		            
		            if(items[2]!=''){
		            	var owners = items[2];
		            	var ownerChecked = owners.split(",");
		            	for(i=0;i<(ownerChecked.length-1);i++){
		            		uncheckRadio(ownerChecked[i],address);
		            	}
		            }
		            if(items[3]!=''){
		            	var subs = items[3];
		            	var subsChecked = subs.split(",");
		            	for(i=1;i<(subsChecked.length-1);i++){
		            		uncheckRadio(subsChecked[i],address);
		            	}
		            }
		           
		            $('#table_overlayer').hide();
		        },
		        error: function (err) {
		            alert(err);
		        }
		    });
		}else{
			 object.attr('checked','');
			 $('#table_overlayer').hide();
		}
		
	}else{
		var limit = parseInt($('#hcheckLimit').val());
		$('#hcheckLimit').val(--limit);
		$("#numberCount_div").show(500);
		$(".numberHCount").html(' در حال بارگذاری شاخه ها ...');
		$(".numberICount").html(' در حال بارگذاری شاخه ها ...');	
		$.ajax({
	        type: "GET",
	        url: address,
	        data: "branchId=" + branchId,
	        success: function (content) {
	        	var str = content;
		        var items = str.split(";");
	        	var lastBranchID = $("#hSelectedRadio").val();
	        	var lastNumberHCount = parseInt($("#hNumberHCount").val());
	        	var lastNumberICount = parseInt($("#hNumberICount").val());
	            $(".numberHCount").html(lastNumberHCount-parseInt(items[0]));
	            $(".numberICount").html(lastNumberICount-parseInt(items[1]));
	            $("#hNumberHCount").val(lastNumberHCount-parseInt(items[0]));
	            $("#hNumberICount").val(lastNumberICount-parseInt(items[1]));
	        	
				var newBranchIds = lastBranchID.replace(branchId+",", "");
				$("#hSelectedRadio").val(newBranchIds);
				
		      
				$('#table_overlayer').hide();
	        },
	        error: function (err) {
	            alert(err);
	        }
	    });	
	}


}

function unCheckGroup(groupId) {
    var chk = "#chkGroup_" + groupId;
    $(chk).attr("checked", "");

}

function getGroupIds() {

    var ids = '';
    $(".dtbl input").each(function (i) {

        if ($(this).is(":checked")) {
            ids += $(this).attr("id").replace('chkGroup_', '') + ',';
        }


    });

    return ids;
}


function BranchCount(Count,BranchID) {
Current=parseInt($(".numberHCount").html());
//alert(Current);
if($("#chkGroup_"+BranchID).is(':checked'))
{
    Count=Current+Count;
}
else
{
    Count=Current-Count;
}

$(".numberHCount").html(Count);

}

function CalcCost()
{
  request_count=$("#request_count").val();
  message_count=parseInt($("#dummyID_MsgBolblSms").html());
  tarrif=parseInt(ShowTarrif(request_count)) ;
  $("#result_cost").html(request_count*tarrif*message_count);
 
  

}



function insertAtCaret(areaId,text) {
    var txtarea = document.getElementById(areaId);
    var scrollPos = txtarea.scrollTop;
    var strPos = 0;
    var br = ((txtarea.selectionStart || txtarea.selectionStart == '0') ? 
        "ff" : (document.selection ? "ie" : false ) );
    if (br == "ie") { 
        txtarea.focus();
        var range = document.selection.createRange();
        range.moveStart ('character', -txtarea.value.length);
        strPos = range.text.length;
    }
    else if (br == "ff") strPos = txtarea.selectionStart;

    var front = (txtarea.value).substring(0,strPos);  
    var back = (txtarea.value).substring(strPos,txtarea.value.length); 
    txtarea.value=front+text+back;
    strPos = strPos + text.length;
    if (br == "ie") { 
        txtarea.focus();
        var range = document.selection.createRange();
        range.moveStart ('character', -txtarea.value.length);
        range.moveStart ('character', strPos);
        range.moveEnd ('character', 0);
        range.select();
    }
    else if (br == "ff") {
        txtarea.selectionStart = strPos;
        txtarea.selectionEnd = strPos;
        txtarea.focus();
    }
    txtarea.scrollTop = scrollPos;
}


function Ext(f)
{
    var ext = $('#'+f).val().split('.').pop().toLowerCase();
    if($.inArray(ext,['jpg','jpeg']) == -1) {
        return 0;
    }
}