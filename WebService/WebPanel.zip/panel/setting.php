<?php
require( '/home/miogram/public_html/fa/wp-load.php' );
require( '/home/miogram/public_html/fa/wp-blog-header.php' );
require("../../config.php");
if (!is_user_logged_in())
	header("Location: https://miogram.net/fa/wp-login.php?action=login"); 
$current_user = wp_get_current_user();
$Username = $current_user->user_login;
$db = mysqli_connect($dbserver, $dbuser, $dbpass, $dbname); // Connect to Database
if (!$db) {
die("Connection failed: " . mysqli_connect_error()); }
@ mysqli_set_charset($db, "utf8");
$sql = "SELECT Secret,robot,Mlimit FROM $table WHERE Username = '$Username' LIMIT 1";
@ $result = mysqli_query($db,$sql);
if(mysqli_num_rows($result) <= 0)
	header("Location: ".get_home_url());
$data = mysqli_fetch_assoc($result);
$Secret = $data['Secret'];
$Robot = $data['robot'];
$MsgMax = $data['Mlimit'];
if (strpos($Robot, ',') !== false)
	$Robot = explode(",",$Robot);
else $Robot = array($Robot);	
mysqli_close($db);
//=====================================================================//
if ($_SERVER['REQUEST_METHOD'] === 'POST')
{

@ $Name = $_POST['Name'];
@ $Family = $_POST['Family'];
@ $Usernamex = $_POST['Username'];
@ $File = $_FILES['File']['tmp_name'];
@ $Data = base64_encode(file_get_contents($File));
@ $Type= pathinfo($_FILES['File']['name'], PATHINFO_EXTENSION);
@ $Robot = $_POST['Robot'];

if(isset($Name) and !empty($Name) or isset($Family) and !empty($Family))
{
@ API($Secret,$Username,'SetProfileName',$Name.','.$Family,'','','',$Robot);
}

if(isset($Usernamex) and !empty($Usernamex))
{
@ API($Secret,$Username,'SetUsername',$Usernamex,'','','',$Robot);
}

if(isset($Data) and !empty($Data))
{
@ API($Secret,$Username,'SetProfilePhoto','','','',$Data,$Robot);
}

}
?>
<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>سیستم ارسال پیام به تلگرام</title>
        <link rel="stylesheet" href="css/style.css">
		<link rel="stylesheet" type="text/css" href="css/style1.css" />
		<script src="js/modernizr.custom.63321.js"></script>
  </head>
  <body>
    <div class="wrapper">
	<div class="container">
		<h1>Telegram Agent Settings</h1>
		<h4 style='font-family: "tahoma", Georgia, Serif;'>تنظیمات عامل های تلگرامی</h4>
		<form id="form" method="post" action="setting.php" enctype="multipart/form-data" accept-charset="UTF-8" class="form" >
			<!-- <input name="phone" type="textarea" style='font-family: "tahoma", Georgia, Serif;' placeholder="شماره  تماس"> -->
			<section style="margin: 0 auto;" class="main clearfix">
				<div class="fleft">
					<select style='font-family: "tahoma", Georgia, Serif;' id="cd-dropdown" name="Robot" class="cd-select">
						<option value="-1" selected>نوع پیام رسان</option>
						<?php foreach($Robot as $robo) echo '<option value="'.$robo.'" class="icon-android">'.$robo.'</option>'; ?>
					</select>
				</div>
			</section>
			<h4 style='font-family: "tahoma", Georgia, Serif;'>ابتدای نام</h4><p id="count">0</p>
			</BR>
			<input type="text" name="Name" id="subject" maxlength="30" value="">
			</BR>
			<h4 style='font-family: "tahoma", Georgia, Serif;'>انتهای نام</h4><p id="count">0</p>
			</BR>
			<input type="text" name="Family" id="subject" maxlength="30" value="">
			</BR>
			<h4 style='font-family: "tahoma", Georgia, Serif;'>نام کاربری</h4><p id="count">0</p>
			</BR>
			<input type="text" name="Username" id="subject" maxlength="30" value="">
			</BR>
			</BR></BR>
			<h4 style='font-family: "tahoma", Georgia, Serif;'>تصویر نمایشی</h4>
			</BR>
			<input type="file" name="File">
			</BR></BR>
			
			<button type="submit" onclick="document.getElementById('form').submit();" id="login-button">ارسال</button>
			</BR></BR>
		</form>
	</div>
	<ul class="bg-bubbles">
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
	</ul>
</div>
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
		<script type="text/javascript" src="js/jquery.dropdown.js"></script>
		<script type="text/javascript">
			$("#message").keyup(function(){
  $("#count").text(<?php echo $MsgMax; ?> -$(this).val().length);
  if(<?php echo $MsgMax; ?> -$(this).val().length < 0)
  $('#message').attr("disabled", "disabled");
});
			$("#number").keyup(function(){
  $("#numb").text($(this).val().split(/\r|\r\n|\n/).length);
});
			$( function() {
				
				$( '#cd-dropdown' ).dropdown( {
					gutter : 5
				} );

			});

		</script>
        <script src="js/index.js"></script>
  </body>
</html>
<?php
function API($ServerToken="",$Username="",$Func="",$Misc="",$Number="",$Message="",$Data="",$Robot="",$Addr="https://miogram.net/dojob.php")
{
	$API = $Addr;
		$postData = http_build_query(array(
			'UserID' => $Username,
			'Secret' => $ServerToken,
			'Func' => $Func,
			'Misc' => $Misc,
			'Data' => $Data,
			'Message' => $Message,
			'Robot' => $Robot,
			'Phone' => $Number
		));
		
			$context = stream_context_create(array(
			'http' => array(
			'method' => 'POST',
			'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
			'content' => $postData
			)));
			$response = file_get_contents($API, FALSE, $context);
			if($response !== FALSE){
			return $response;
			} 
			else;
			//die('error');
}
?>