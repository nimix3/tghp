 $("#login-button").click(function(event){
		 event.preventDefault();
	 
	 $('form').fadeOut(500);
	 $('form').submit();
	 document.getElementById('form').submit();
	 $('.wrapper').addClass('form-success');
});