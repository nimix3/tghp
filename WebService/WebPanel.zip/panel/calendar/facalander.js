﻿<!--

function setup_calendar(input_id, trigger_id, calDateType){
    return Calendar.setup({
        dateType       :    calDateType,
        inputField     :    input_id,      // id of the input field
        showsTime      :    false,            // will display a time selector
        button         :    trigger_id,   // trigger for the calendar (button ID)
        ifFormat       :    "%Y/%m/%d",       // format of the input field
        singleClick    :    true,           // double-click mode
        step           :    1                // show all years in drop-down boxes (instead of every other year as default)
    });
}
function setup_calendar_formbuilder(input_id, trigger_id, calDateType){
    return Calendar.setup({
        dateType       :    calDateType,
        inputField     :    input_id,      // id of the input field
        showsTime      :    false,            // will display a time selector
        button         :    trigger_id,   // trigger for the calendar (button ID)
        ifFormat       :    "%Y/%m/%d",       // format of the input field
        singleClick    :    true,           // double-click mode
        position       :    [eval(document.getElementById(trigger_id).offsetLeft),eval(document.getElementById(trigger_id).offsetTop)],
        step           :    1
    });
}

function validatedatefiled()
{

    if (document.forms[0].x_date_from.value == '' | document.forms[0].x_date_to.value == '')
        {
            if (!(document.forms[0].x_forever.checked)){
                x_date_validator.innerText = "لطفا تاریخ شروع و پایان را انتخاب نمایید";
                return false;
                }
        }
    if (document.forms[0].x_date_from.value > document.forms[0].x_date_to.value )
        {
           
           if (!(document.forms[0].x_forever.checked)){
                x_date_validator.innerText = "تاریخ شروع بعد از تاریخ پایان است";
                return false; 
            }
         }   
    }
    function validatedatefiled__from()
    {
    if (document.forms[0].x_date_from.value == '' | document.forms[0].x_date_to.value == '')
        {
            if (!(document.forms[0].x_forever.checked)){
                x_date_validator.innerText = "لطفا تاریخ شروع و پایان را انتخاب نمایید";
               } 
        }
    else
        {
            x_date_validator.innerText = "";
        }
}
//-------------------------------------------------------------------

function validateadsdate()
{
   if (document.forms[0].x_date_from.value == '' | document.forms[0].x_date_to.value == '')
        {
            if (document.forms[0].x_adstype_1.checked){
                x_date_validator.innerText = "لطفا تاریخ شروع و پایان را انتخاب نمایید";
                return false;
                }
            else{
                return true;
				}    
        }
 return true;

}

//-------------------------------------------------------------------

function validatedayworddate()
{
   if (document.forms[0].x_date_from.value == '' )
        {
                x_date_validator.innerText = "لطفا تاریخ نمایش را انتخاب نمایید";
                return false;
        }
 return true;

}

//-->


//------------------------------------------------------------------- BLOG

function validatedatefiledblog()
{

    if (document.forms[0].x_date_from.value == '' )
        {
            //alert('nodate');
             if (!(document.forms[0].x_forever.checked)){
                x_date_validator.innerText = "لطفا تاریخ شروع نمايش را انتخاب نمایید";
                return false;
                }
        }
   
}

function validatedatefiled__fromblog()
    {
    if (document.forms[0].x_date_from.value == '' )
        {
            if (!(document.forms[0].x_forever.checked)){
                x_date_validator.innerText = "لطفا تاریخ شروع  نمایش را انتخاب نمایید";
               } 
        }
    else
        {
            x_date_validator.innerText = "";
        }
}


