



<!DOCTYPE html>

<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!--> <html lang="en" class="no-js"> <!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
	<meta charset="utf-8" />
	<title>سامانه ارسال پیام تلگرام</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1.0" name="viewport" />
	<meta content="" name="description" />
	<meta content="" name="author" />
	<meta name="MobileOptimized" content="320">
	<!-- BEGIN GLOBAL MANDATORY STYLES -->          
	<link href="assets/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
	<link href="assets/plugins/bootstrap/css/bootstrap-rtl.min.css" rel="stylesheet" type="text/css"/>

	<!-- END GLOBAL MANDATORY STYLES -->
	<!-- BEGIN PAGE LEVEL PLUGIN STYLES --> 
	<link href="assets/plugins/gritter/css/jquery.gritter-rtl.css" rel="stylesheet" type="text/css"/>
	<link href="assets/plugins/bootstrap-daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
	<link href="assets/plugins/fullcalendar/fullcalendar/fullcalendar.css" rel="stylesheet" type="text/css"/>
	<link href="assets/plugins/jquery-easy-pie-chart/jquery.easy-pie-chart.css" rel="stylesheet" type="text/css"/>
	<!-- END PAGE LEVEL PLUGIN STYLES -->
	<!-- BEGIN THEME STYLES --> 
	<link href="assets/css/style-metronic-rtl.css" rel="stylesheet" type="text/css"/>
	<link href="assets/css/style-rtl.css" rel="stylesheet" type="text/css"/>
	<link href="assets/css/style-responsive-rtl.css" rel="stylesheet" type="text/css"/>
	<link href="assets/css/plugins-rtl.css" rel="stylesheet" type="text/css"/>
	<link href="assets/css/pages/tasks-rtl.css" rel="stylesheet" type="text/css"/>  
	<link href="assets/css/themes/green.css" rel="stylesheet" type="text/css" id="style_color"/>
	<link href="assets/css/custom-rtl.css" rel="stylesheet" type="text/css"/>
	<script src="assets/plugins/jquery-1.10.2.min.js" type="text/javascript"></script>
	<!-- END THEME STYLES -->

<link href="template/default/css/facebox.css" type="text/css" rel="stylesheet" /> 
<script language="javascript" src="template/default/js/facebox.js"></script>
<script language="javascript" src="template/default/js/ui.js"></script>
<script language="javascript" src="template/default/js/ewp.js"></script>


<script  type="text/javascript" src="chart/charts/highcharts.js"></script>
<script  type="text/javascript" src="chart/charts/modules/exporting.js"></script>
<script  type="text/javascript" src="chart/charts/themes/gray.js"></script>
<!-- alert -->
<script src="template/default/js/jquery.alerts.js" type="text/javascript"></script>
<link href="template/default/css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
<link rel="stylesheet" type="text/css" href="template/default/css/header.css" />
<link rel="stylesheet" type="text/css" href="template/default/css/default.css" />



<script language="javascript" src="template/default/js/jquery-cookie.js"></script>
<script language="javascript" src="calendar/facalander.js"></script>
<script language="javascript" src="calendar/jalali.js"></script>
<script language="javascript" src="calendar/calendar-en.js"></script>
<script language="javascript" src="calendar/calendar-JA.js"></script>
<link media="all" href="css/calendar-win2k-1.css" type="text/css" rel="stylesheet">
<script src="calendar/js_005.js" type="text/javascript"></script>
<script src="calendar/js_006.js" type="text/javascript"></script>
 <script src="calendar/js_003.js" type="text/javascript"></script>



   
<script type="text/javascript">
<!--
EW_LookupFn = "ewlookup.php"; // ewlookup file name
EW_AddOptFn = "ewaddopt.php"; // ewaddopt.php file name

//-->

</script>
<script type="text/javascript" src="http://www.telegrampanel.com/ewp.js"></script>
<script type="text/javascript">
<!--
EW_dateSep = "/"; // set date separator
EW_UploadAllowedFileExt = "gif,jpg,jpeg,bmp,png,doc,xls,pdf,zip"; // allowed upload file extension

//-->
</script>

<script type="text/javascript">
<!--
	var EW_DHTMLEditors = [];

//-->
</script>
<form name="ftransactionadd" id="ftransactionadd" action="test.htm" method="post" onSubmit="return EW_checkMyForm(this);">
<p>
<input type="hidden" name="a_add" value="A">



<script language="javascript">
function GetResult()
{

val=document.getElementById("x_mobile").value;
if(val=="")
{
    alert("شماره موبایل را وارد نمایید");
    return;
}

</script> 

       <!-- BEGIN BODY-->        
        <div class="row">
            <div class="col-md-12">
               <!-- BEGIN EXAMPLE TABLE PORTLET-->
               <div class="portlet box green">
                  <div class="portlet-title">
                     <div class="caption"><i class="icon-edit"></i>تست ارسال تلگرام</div>
                     <div class="tools">
                        <a class="collapse" href="javascript:;"></a>
                        <a class="reload" href="javascript:;"></a>
                        <a class="remove" href="javascript:;"></a>
                     </div>
                  </div>
                  <div class="portlet-body">
                     <div class="table-toolbar">
                        <div id="dropdown_glyphicon" class="tab-pane active">
                        



<table id="sample_editable_1" class="table table-striped table-hover table-bordered dataTable" aria-describedby="sample_editable_1_info">

	<tr>
		<td class="ewTableHeader"><span style="font-size:130%;">شماره موبایل خود را وارد نمایید</span></td>
		<td class="ewTableAltRow"><span id="cb_x_mobile">
<input type="text" name="x_mobile" id="x_mobile" size="30" maxlength="110"   >

</span></td>
	</tr>

        	<tr>
		<td class="ewTableHeader"><span>کد امنیتی<span class='ewmsg'>&nbsp;*</span></span>

        </td>
		<td class="ewTableAltRow"><div style="float: right;"><input type="text" name="security_code" /></div>
        <div style="float: right; margin: 0px 10px 5px 0px;"><img src="http://www.telegrampanel.com/CaptchaSecurityImages.php" /></div>
        
        
        </td>
       

	</tr>
	<tr>
		
<td colspan="2">
<input type="submit" value="ارسال تست تلگرام" id="btnAction" class="btn green" />

</td>
       

	</tr>
    
    
</table>
<p>

</form>
</div>
</div>
</div>
</div>
				</div>
			<!-- END BODY-->	
        
        </div>
		<!-- END PAGE -->
	</div>
	<!-- END CONTAINER -->
	<!-- BEGIN FOOTER -->
	<div class="footer">
		<div class="footer-inner">
			
		</div>
		<div class="footer-tools">
			<span class="go-top">
			<i class="icon-angle-up"></i>
			</span>
		</div>
	</div>
	<!-- END FOOTER -->
	<!-- BEGIN JAVASCRIPTS(Load javascripts at bottom, this will reduce page load time) -->
	<!-- BEGIN CORE PLUGINS -->   
	<!--[if lt IE 9]>
	<script src="assets/plugins/respond.min.js"></script>
	<script src="assets/plugins/excanvas.min.js"></script> 
	<![endif]-->   

	<script src="assets/plugins/jquery-migrate-1.2.1.min.js" type="text/javascript"></script>   
	<!-- IMPORTANT! Load jquery-ui-1.10.3.custom.min.js before bootstrap.min.js to fix bootstrap tooltip conflict with jquery ui tooltip -->
	<script src="assets/plugins/jquery-ui/jquery-ui-1.10.3.custom.min.js" type="text/javascript"></script>
	<script src="assets/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="assets/plugins/bootstrap-hover-dropdown/twitter-bootstrap-hover-dropdown.min.js" type="text/javascript" ></script>
	<script src="assets/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
	<script src="assets/plugins/jquery.blockui.min.js" type="text/javascript"></script>  
	<script src="assets/plugins/jquery.cookie.min.js" type="text/javascript"></script>
	<script src="assets/plugins/uniform/jquery.uniform.min.js" type="text/javascript" ></script>
	<!-- END CORE PLUGINS -->
	<!-- BEGIN PAGE LEVEL PLUGINS -->
	<script src="assets/plugins/flot/jquery.flot.js" type="text/javascript"></script>
	<script src="assets/plugins/flot/jquery.flot.resize.js" type="text/javascript"></script>
	<script src="assets/plugins/jquery.pulsate.min.js" type="text/javascript"></script>
	<script src="assets/plugins/bootstrap-daterangepicker/moment.min.js" type="text/javascript"></script>
	<script src="assets/plugins/bootstrap-daterangepicker/daterangepicker.js" type="text/javascript"></script>     
	<script src="assets/plugins/gritter/js/jquery.gritter.js" type="text/javascript"></script>
	<!-- IMPORTANT! fullcalendar depends on jquery-ui-1.10.3.custom.min.js for drag & drop support -->
	<script src="assets/plugins/fullcalendar/fullcalendar/fullcalendar.min.js" type="text/javascript"></script>
	<script src="assets/plugins/jquery-easy-pie-chart/jquery.easy-pie-chart.js" type="text/javascript"></script>
	<script src="assets/plugins/jquery.sparkline.min.js" type="text/javascript"></script>  
	<!-- END PAGE LEVEL PLUGINS -->
	<!-- BEGIN PAGE LEVEL SCRIPTS -->
	<script src="assets/scripts/app.js" type="text/javascript"></script>
	<script src="assets/scripts/index.js" type="text/javascript"></script>
	<script src="assets/scripts/tasks.js" type="text/javascript"></script>        
	<!-- END PAGE LEVEL SCRIPTS -->  
	<script>
    
            // Tooltip only Text
        $('.masterTooltip').hover(function(){
                // Hover over code
                var title = $(this).attr('title');
                $(this).data('tipText', title).removeAttr('title');
                $('<p class="tooltip"></p>')
                .text(title)
                .appendTo('body')
                .fadeIn('slow');
        }, function() {
                // Hover out code
                $(this).attr('title', $(this).data('tipText'));
                $('.tooltip').remove();
        }).mousemove(function(e) {
                var mousex = e.pageX + 20; //Get X coordinates
                var mousey = e.pageY + 10; //Get Y coordinates
                $('.tooltip')
                .css({ top: mousey, left: mousex })
        });
        
		jQuery(document).ready(function() {    
		   App.init(); // initlayout and core plugins
		   Index.init();
		  // Index.initJQVMAP(); // init index page's custom scripts
		   Index.initCalendar(); // init index page's custom scripts
		   Index.initCharts(); // init index page's custom scripts
		   Index.initChat();
		   Index.initMiniCharts();
		   Index.initDashboardDaterange();
		   Index.initIntro();
		   Tasks.initDashboardWidget();
		});
	</script>
	<!-- END JAVASCRIPTS -->
</body>
<!-- END BODY -->
</html>