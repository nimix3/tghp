<?php
require( '/home/miogram/public_html/fa/wp-load.php' );
require( '/home/miogram/public_html/fa/wp-blog-header.php' );
require("../../config.php");
if (!is_user_logged_in())
	header("Location: https://miogram.net/fa/wp-login.php?action=login"); 
$current_user = wp_get_current_user();
$Username = $current_user->user_login;
$db = mysqli_connect($dbserver, $dbuser, $dbpass, $dbname); // Connect to Database
if (!$db) {
die("Connection failed: " . mysqli_connect_error()); }
@ mysqli_set_charset($db, "utf8");
$sql = "SELECT Secret,IP,robot FROM $table WHERE Username = '$Username' LIMIT 1";
@ $result = mysqli_query($db,$sql);
if(mysqli_num_rows($result) <= 0)
	header("Location: ".get_home_url());
$data = mysqli_fetch_assoc($result);
@ $Secret = $data['Secret'];
@ $TheIP = $data["IP"];
@ $Robot = $data["robot"];
mysqli_close($db);
//=====================================================================//
?>
<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>سیستم ارسال پیام به تلگرام</title>
        <link rel="stylesheet" href="css/style2.css">
  </head>
  <body>
    <div class="wrapper">
	<div class="container">
		<BR>
		<h1>WebService Information</h1>
		<h4 style='font-family: "tahoma", Georgia, Serif;'>سیستم اطلاعات وب سرویس</h4>
		<BR><BR>
        <h3 style='font-family: "tahoma", Georgia, Serif;'>Secret : <?php echo $Secret; ?></h3>
		<BR>
		<h3 style='font-family: "tahoma", Georgia, Serif;'>Allow IP : <?php echo $TheIP; ?></h3>
		<BR>
		<h3 style='font-family: "tahoma", Georgia, Serif;'>Agents : <?php echo $Robot; ?></h3>
		<BR>
         <a href="#" onclick="window.reload(true);">بارگزاری مجدد</a><BR>
		<form id="form" class="form" action="#" >
			<button type="button" onclick="window.open('https://miogram.net/fa/api/');" >مستندات وب سرویس</button>
			<button type="button" onclick="window.open('https://miogram.net/fa/%D8%A2%D9%85%D9%88%D8%B2%D8%B4/');">راهنمای سیستم</button>
			<BR><BR>
			<button type="button" onclick="window.open('https://miogram.net/fa/plugins/');">پلاگین ها</button>
			<button type="button" onclick="window.open('https://miogram.net/fa/check/');">تست وب سرویس</button>
        </form>
	</div>
	<ul class="bg-bubbles">
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
	</ul>
</div>
  </body>
</html>
<?php
function API($ServerToken="",$Username="",$Func="",$Misc="",$Number="",$Message="",$Data="",$Addr="https://miogram.net/dojob.php")
{
	$API = $Addr;
		$postData = http_build_query(array(
			'UserID' => $Username,
			'Secret' => $ServerToken,
			'Func' => $Func,
			'Misc' => $Misc,
			'Data' => $Data,
			'Message' => $Message,
			'Phone' => $Number
		));
		
			$context = stream_context_create(array(
			'http' => array(
			'method' => 'POST',
			'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
			'content' => $postData
			)));
			$response = file_get_contents($API, FALSE, $context);
			if($response !== FALSE){
			return $response;
			} 
			else;
			//die('error');
}
?>