
<!DOCTYPE html>

<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!--> <html lang="en" class="no-js"> <!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
   <meta charset="utf-8" />
   <title>سامانه ارسال پیام تبلیغاتی تلگرام</title>
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta content="width=device-width, initial-scale=1.0" name="viewport" />
   <meta content="" name="description" />
   <meta content="" name="author" />
   <meta name="MobileOptimized" content="320">
   <!-- BEGIN GLOBAL MANDATORY STYLES -->          
   <link href="assets/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
   <link href="assets/plugins/bootstrap/css/bootstrap-rtl.min.css" rel="stylesheet" type="text/css"/>
   <link href="http://www.telegrampanel.com/assets/plugins/uniform/css/uniform.default.css" rel="stylesheet" type="text/css"/>
   <!-- END GLOBAL MANDATORY STYLES -->
   <!-- BEGIN PAGE LEVEL STYLES --> 
   <link rel="stylesheet" type="text/css" href="http://www.telegrampanel.com/assets/plugins/select2/select2_metro_rtl.css" />
   <!-- END PAGE LEVEL SCRIPTS -->
   <!-- BEGIN THEME STYLES --> 
   <link href="assets/css/style-metronic-rtl.css" rel="stylesheet" type="text/css"/>
   <link href="assets/css/style-rtl.css" rel="stylesheet" type="text/css"/>
   <link href="assets/css/style-responsive-rtl.css" rel="stylesheet" type="text/css"/>
   <link href="assets/css/plugins-rtl.css" rel="stylesheet" type="text/css"/>
   <link href="http://www.telegrampanel.com/assets/css/themes/default-rtl.css" rel="stylesheet" type="text/css" id="style_color"/>
   <link href="http://www.telegrampanel.com/assets/css/pages/login-soft-rtl.css" rel="stylesheet" type="text/css"/>
   <link href="assets/css/custom-rtl.css" rel="stylesheet" type="text/css"/>
   <!-- END THEME STYLES -->
      <script src="assets/plugins/jquery-1.10.2.min.js" type="text/javascript"></script>
      



    
<!DOCTYPE html>

<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!--> <html lang="en" class="no-js"> <!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
	<meta charset="utf-8" />
	<title>سامانه ارسال پیام تلگرام</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1.0" name="viewport" />
	<meta content="" name="description" />
	<meta content="" name="author" />
	<meta name="MobileOptimized" content="320">
	<!-- BEGIN GLOBAL MANDATORY STYLES -->          
	<link href="assets/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
	<link href="assets/plugins/bootstrap/css/bootstrap-rtl.min.css" rel="stylesheet" type="text/css"/>

	<!-- END GLOBAL MANDATORY STYLES -->
	<!-- BEGIN PAGE LEVEL PLUGIN STYLES --> 
	<link href="assets/plugins/gritter/css/jquery.gritter-rtl.css" rel="stylesheet" type="text/css"/>
	<link href="assets/plugins/bootstrap-daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
	<link href="assets/plugins/fullcalendar/fullcalendar/fullcalendar.css" rel="stylesheet" type="text/css"/>
	<link href="assets/plugins/jquery-easy-pie-chart/jquery.easy-pie-chart.css" rel="stylesheet" type="text/css"/>
	<!-- END PAGE LEVEL PLUGIN STYLES -->
	<!-- BEGIN THEME STYLES --> 
	<link href="assets/css/style-metronic-rtl.css" rel="stylesheet" type="text/css"/>
	<link href="assets/css/style-rtl.css" rel="stylesheet" type="text/css"/>
	<link href="assets/css/style-responsive-rtl.css" rel="stylesheet" type="text/css"/>
	<link href="assets/css/plugins-rtl.css" rel="stylesheet" type="text/css"/>
	<link href="assets/css/pages/tasks-rtl.css" rel="stylesheet" type="text/css"/>  
	<link href="assets/css/themes/green.css" rel="stylesheet" type="text/css" id="style_color"/>
	<link href="assets/css/custom-rtl.css" rel="stylesheet" type="text/css"/>
	<script src="assets/plugins/jquery-1.10.2.min.js" type="text/javascript"></script>
	<!-- END THEME STYLES -->

<link href="template/default/css/facebox.css" type="text/css" rel="stylesheet" /> 
<script language="javascript" src="template/default/js/facebox.js"></script>
<script language="javascript" src="template/default/js/ui.js"></script>
<script language="javascript" src="template/default/js/ewp.js"></script>


<script  type="text/javascript" src="chart/charts/highcharts.js"></script>
<script  type="text/javascript" src="chart/charts/modules/exporting.js"></script>
<script  type="text/javascript" src="chart/charts/themes/gray.js"></script>
<!-- alert -->
<script src="template/default/js/jquery.alerts.js" type="text/javascript"></script>
<link href="template/default/css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
<link rel="stylesheet" type="text/css" href="template/default/css/header.css" />
<link rel="stylesheet" type="text/css" href="template/default/css/default.css" />



<script language="javascript" src="template/default/js/jquery-cookie.js"></script>
<script language="javascript" src="calendar/facalander.js"></script>
<script language="javascript" src="calendar/jalali.js"></script>
<script language="javascript" src="calendar/calendar-en.js"></script>
<script language="javascript" src="calendar/calendar-JA.js"></script>
<link media="all" href="css/calendar-win2k-1.css" type="text/css" rel="stylesheet">
<script src="calendar/js_005.js" type="text/javascript"></script>
<script src="calendar/js_006.js" type="text/javascript"></script>
 <script src="calendar/js_003.js" type="text/javascript"></script>



      <link rel="shortcut icon" href="http://www.telegrampanel.com/favicon.ico" />
   
</head>
 <script type="text/javascript">
        var browserAlert = false;
        var url = '';
        var browser = '';

        $(document).ready(function () {


            $('a[rel*=facebox]').facebox()


            jQuery.each(jQuery.browser, function (i, val) {
                if (val)
                    browser = i;
            });

            if (browser == "mozilla" && parseFloat(jQuery.browser.version.substr(0, 3)) < 1.5) {
                browserAlert = true;
                url = '<a href="http://www.mozilla.com/en-US/firefox/upgrade.html">دانلود ورژن جديد</a>';
            }
            else if (browser == "msie" && parseFloat(jQuery.browser.version.substr(0, 3)) < 7) {

                browserAlert = true;
                url = '<a href="http://www.microsoft.com/windows/internet-explorer/default.aspx">دانلود ورژن جديد</a>';
            }

            if (browserAlert)
                $.growlUI('مرورگر', 'نسخه مرورگري که شما استفاده مي کنيد قديمي است<br>براي دريافت نسخه جديد بر روي لينک زير کليک نماييد<br>' + url, 10000);


            	$("#confirm_button").click( function() {
					jConfirm('آيا قصد خروج از سامانه را داريد ؟', 'تاييد خروج', function(r) {
						if(r){ window.location="logout.php"};
					});
				});
                
            
        });
        
        
        
        
        
        
    </script>
<!-- END HEAD -->
<!-- BEGIN BODY -->
<body class="login">
   <!-- BEGIN LOGO -->
   <div class="logo">
   <img src="http://www.telegrampanel.com/logo/default_big.png" alt=""  style="width:218px;height:72px" />       
   </div>
   <!-- END LOGO -->
   <!-- BEGIN LOGIN -->
   <div class="content1" >
      <!-- BEGIN LOGIN FORM -->
      <form class="login-form" action="login_29.htm" method="post">
         <h3 class="form-title" style="font-family: BYekan,'BYekan',tahoma;">ورود به سامانه</h3>
       
         
<div class="note note-warning ">جهت تست با نام کاربری demo و کلمه عبور demo وارد شوید</div>
        <br />     
            <span style="color: #ff0000;">         لطفا جهت عملکرد بهتر سامانه از مرورگر های فایرفاکس یا کروم استفاده نمایید</span>

         <div class="form-group">
            <!--ie8, ie9 does not support html5 placeholder, so we just show field title for that-->
            <label class="control-label visible-ie8 visible-ie9">نام کاربری</label>
            <div class="input-icon">
               <i class="icon-user"></i>
               <input class="form-control placeholder-no-fix" type="text" autocomplete="off" placeholder="نام کاربری" name="Username" value="" />
            </div>
         </div>
         <div class="form-group">
            <label class="control-label visible-ie8 visible-ie9">کلمه عبور</label>
            <div class="input-icon">
               <i class="icon-lock"></i>
               <input class="form-control placeholder-no-fix" type="password" autocomplete="off" placeholder="کلمه عبور" name="Password" value="" />
            </div>
         </div>
         
         <div class="form-actions">
        
            <button type="submit" class="btn blue pull-right">
            ورود <i class="m-icon-swapright m-icon-white"></i>
            </button>            
         </div>
         <div class="forget-password" style="clear: both;width:100%;margin-top: 0px;">
                        <a class="btn red" target="_blank" href="http://www.telegrampanel.com/register.php" style="width: 150px;">خرید پنل تلگرام</a>
                                    
                  <a class="btn green" rev="iframe|750|350" rel="[facebox]" href="test.htm" style="width: 130px;">تست ارسال تلگرام</a>
                  </div>
         <div class="create-account">
       <a class="btn purple" rev="iframe|750|350" rel="[facebox]" href="http://www.telegrampanel.com/reset.php" style="width: 170px;">فراموشی کلمه عبور</a>
         </div>
      </form>
      <!-- END LOGIN FORM -->        
      <!-- BEGIN FORGOT PASSWORD FORM -->
      <form class="forget-form" action="http://www.telegrampanel.com/index.html" method="post">
         <h3 >Forget Password ?</h3>
         <p>Enter your e-mail address below to reset your password.</p>
         <div class="form-group">
            <div class="input-icon">
               <i class="icon-envelope"></i>
               <input class="form-control placeholder-no-fix" type="text" autocomplete="off" placeholder="Email" name="email" />
            </div>
         </div>
         <div class="form-actions">
            <button type="button" id="back-btn" class="btn">
            <i class="m-icon-swapleft"></i> Back
            </button>
            <button type="submit" class="btn blue pull-right">
            Submit <i class="m-icon-swapright m-icon-white"></i>
            </button>            
         </div>
      </form>
      <!-- END FORGOT PASSWORD FORM -->
  
   </div>
   <!-- END LOGIN -->
   <!-- BEGIN COPYRIGHT -->
   <div class="copyright">
                  02188044144   </div>
      <div class="copyright">
                     </div>
      <div class="copyright">   </div>
   
  <div style="position:fixed; Left:-20px; bottom:10px; z-index:1000;"> </div>
   
   </div>
   <!-- END COPYRIGHT -->
   <!-- BEGIN JAVASCRIPTS(Load javascripts at bottom, this will reduce page load time) -->
   <!-- BEGIN CORE PLUGINS -->   
   <!--[if lt IE 9]>
   <script src="assets/plugins/respond.min.js"></script>
   <script src="assets/plugins/excanvas.min.js"></script> 
   <![endif]-->   

   <script src="assets/plugins/jquery-migrate-1.2.1.min.js" type="text/javascript"></script>
   <script src="assets/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
   <script src="assets/plugins/bootstrap-hover-dropdown/twitter-bootstrap-hover-dropdown.min.js" type="text/javascript" ></script>
   <script src="assets/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
   <script src="assets/plugins/jquery.blockui.min.js" type="text/javascript"></script>  
   <script src="assets/plugins/jquery.cookie.min.js" type="text/javascript"></script>
   <script src="assets/plugins/uniform/jquery.uniform.min.js" type="text/javascript" ></script>
   <!-- END CORE PLUGINS -->
   <!-- BEGIN PAGE LEVEL PLUGINS -->
   <script src="http://www.telegrampanel.com/assets/plugins/jquery-validation/dist/jquery.validate.min.js" type="text/javascript"></script>
   <script src="http://www.telegrampanel.com/assets/plugins/backstretch/jquery.backstretch.min.js" type="text/javascript"></script>
   <script type="text/javascript" src="http://www.telegrampanel.com/assets/plugins/select2/select2.min.js"></script>
   <!-- END PAGE LEVEL PLUGINS -->
   <!-- BEGIN PAGE LEVEL SCRIPTS -->
   <script src="assets/scripts/app.js" type="text/javascript"></script>
   <script src="http://www.telegrampanel.com/assets/scripts/login-soft.js" type="text/javascript"></script>      
   <!-- END PAGE LEVEL SCRIPTS --> 
   <script>
      jQuery(document).ready(function() {     
        App.init();
        Login.init();
      });
   </script>
   <!-- END JAVASCRIPTS -->
</body>
<!-- END BODY -->
</html>